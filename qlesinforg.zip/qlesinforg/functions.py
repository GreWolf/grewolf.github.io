from typing import Optional, Tuple

from qgis.core import QgsVectorLayer, QgsDataSourceUri, QgsDataProvider


def check_layer_exists(obj: Optional[QgsVectorLayer]) -> Optional[QgsVectorLayer]:
    # Проверка существует ли слой вообще и если существует, то не удален ли он (будет ошибка при вызове isValid)
    if obj is not None:
        try:
            obj.isValid()
        except RuntimeError:
            return None
        else:
            return obj
    else:
        return None


def load_layer_from_layer(layer: Optional[QgsVectorLayer], other_layer: QgsVectorLayer, layer_name: str) -> Tuple[
                                                                                                QgsVectorLayer, bool]:
    # Загрузка данных для слоя из другого слоя (other_layer).
    # Если слоя не существует (еще не был создан или был удален),
    # то присваиваем ему другой слой, если слой существует, то переназначаем источник данных в нем
    # и заново добавляем features.
    # Так же если слой существует, то загрузка стиля не требуется (need_style = False)
    if layer is None:
        layer = other_layer
        layer.setName(layer_name)
        need_style = True
    else:
        layer.setDataSource(other_layer.source(), layer_name, layer.providerType(), QgsDataProvider.ProviderOptions())
        layer.dataProvider().addFeatures(other_layer.getFeatures())
        layer.updateExtents()
        need_style = False
    return layer, need_style
    # newlayer = QgsVectorLayer(layer.source(), layer.name(), layer.providerType())

def load_layer_from_db(layer: Optional[QgsVectorLayer], uri: QgsDataSourceUri, layer_name: str) -> Tuple[
                                                                                    QgsVectorLayer, bool]:
    # Загрузка данных (из БД) для слоя. Если слоя не существует (еще не был создан или был удален),
    # то заново создаем объект QgsVectorLayer, если слой существует, то переназначаем источник данных в нем.
    # Так же если слой существует, то загрузка стиля не требуется (need_style = False)
    if layer is None:
        layer = QgsVectorLayer(uri.uri(), layer_name, "postgres")
        need_style = True
    else:
        layer.setDataSource(uri.uri(), layer_name, "postgres", QgsDataProvider.ProviderOptions())
        layer.updateExtents()
        need_style = False
    return layer, need_style


def set_style(layer: QgsVectorLayer, need_style: bool = False, style_path: str = "") -> None:
    # Установка стиля для слоя
    if need_style:
        layer.loadNamedStyle(style_path)

__author__ = 'seminozhenko.ss'
__date__ = '2020-01-10'
__copyright__ = '(C) 2020 by seminozhenko.ss'

__revision__ = '$Format:%H$'

import os
from typing import Dict, Any, List

from processing.modeler.ModelerDialog import ModelerDialog
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingUtils,
                       QgsCoordinateReferenceSystem,
                       QgsProcessingParameterExpression,
                       QgsProcessingParameterBoolean,
                       QgsWkbTypes,
                       QgsProcessingParameterDefinition,
                       QgsProcessingParameterField,
                       QgsProcessingParameterString,
                       QgsProcessingFeedback,
                       QgsProcessingContext,
                       QgsProject,
                       QgsApplication, QgsProcessingFeatureSource, QgsProcessingParameterCrs,
                       QgsProcessingMultiStepFeedback, QgsProcessingParameterEnum,
                       QgsProcessingParameterFolderDestination, QgsFeatureRequest, QgsExpression, QgsVectorLayer
                       )

from ...modules.functions import prepare_path
from ...modules.proximity import find_field

from ...widgets.expression_widget import CustomExpressionWrapper
from ...widgets.field_widget import CustomFieldWrapper
from ...modules.optionParser import parseOptions
from ...modules.proximity import proximity

from ..extract_vertices.extract_vertices import extractVertices
from ..excel_creator.excel_creator import excelCreator


# from modules.functions import prepare_path
# from modules.proximity import find_field
#
# from widgets.expression_widget import CustomExpressionWrapper
# from widgets.field_widget import CustomFieldWrapper
# from modules.optionParser import parseOptions
# from modules.proximity import proximity

from ..extract_vertices.extract_vertices import extractVertices
from ..excel_creator.excel_creator import excelCreator

# эти два импорта не удалять
import processing
from processing.core.Processing import Processing

options = parseOptions(__file__)


class createReport(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    TYPES = 'TYPES'
    FOLDEROUTPUT = 'FOLDEROUTPUT'
    SOLIDNUMBERING = 'SOLIDNUMBERING'
    CRS = 'CRS'
    FILTEREXPRESSION = 'FILTEREXPRESSION'
    GROUPSORT = 'GROUPSORT'

    types = {
        "ОЗУ": {"field": "skp"},
        "Категории защитности": {"field": "mk"},
        "Категория земель": {"field": "zk"}
    }

    destfields = ["sri", "mu", "gir"]
    subdestfields = ["kv", "sknr"]

    def __init__(self, plugin_dir):
        self.__plugin_dir = plugin_dir
        self.extract_vertices = extractVertices(self.__plugin_dir)
        self.excel_creator = excelCreator(self.__plugin_dir)

        super().__init__()

    def initAlgorithm(self, config: Dict[str, Any]):

        self.extract_vertices.initAlgorithm(config)
        self.excel_creator.initAlgorithm(config)

        self.addParameter(QgsProcessingParameterFeatureSource(
            name=self.INPUT,
            description='Выдела',
            types=[QgsProcessing.TypeVectorAnyGeometry],
            defaultValue=None
        ))

        self.addParameter(QgsProcessingParameterEnum(
            name=self.TYPES,
            description='Тип',
            allowMultiple=True,
            options=self.types.keys(),
            defaultValue=options.get(self.TYPES, None)
            # defaultValue="1"
        ))

        param = QgsProcessingParameterCrs(
            name=self.CRS,
            description='Проекция в которой необходимо посчитать координаты точек',
            optional=True,
            defaultValue=options.get(self.CRS, None)
        )

        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterBoolean(
            name=self.SOLIDNUMBERING,
            description='Сплошная нумерация точек',
            defaultValue=options.get(self.SOLIDNUMBERING, None)
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterExpression(
            name=self.GROUPSORT,
            description='Выражение по которому будет присваиваться номер полигону',
            parentLayerParameterName=self.INPUT,
            defaultValue=options.get(self.GROUPSORT, None),
            optional=True
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterExpression(
            name=self.FILTEREXPRESSION,
            description='Выражение для предварительной фильтрации вектора',
            parentLayerParameterName=self.INPUT,
            defaultValue=options.get(self.FILTEREXPRESSION, ""),
            optional=True
        )

        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        self.parameterDefinition(self.FILTEREXPRESSION).setMetadata({
            'widget_wrapper': CustomExpressionWrapper
        })

        self.addParameter(QgsProcessingParameterFolderDestination(
            name=self.FOLDEROUTPUT,
            description="Выходная папка",
            defaultValue=prepare_path(options.get(self.FOLDEROUTPUT, ""), self.__plugin_dir),
        ))

    def processAlgorithm(self, parameters: Dict[str, Any],
                         context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):
        result = dict()

        input: QgsProcessingFeatureSource = self.parameterAsSource(parameters, self.INPUT, context)
        input_indexes: List = self.parameterAsEnums(parameters, self.TYPES, context)

        solidnumbering: bool = self.parameterAsBool(parameters, self.SOLIDNUMBERING, context)

        if parameters[self.CRS]:
            dest_crs: QgsCoordinateReferenceSystem = self.parameterAsCrs(parameters, self.CRS, context)
        else:
            dest_crs = QgsCoordinateReferenceSystem()

        if parameters[self.FILTEREXPRESSION]:
            filterexpression: str = self.parameterAsExpression(parameters, self.FILTEREXPRESSION, context)
        else:
            filterexpression = ""

        if parameters[self.GROUPSORT]:
            groupsort: str = self.parameterAsExpression(parameters, self.GROUPSORT, context)
        else:
            groupsort = ""

        dest_folder = self.parameterAsFile(parameters, self.FOLDEROUTPUT, context)

        input_types = [list(self.types.keys())[input_index] for input_index in input_indexes]

        real_destfields = []
        for destfield in self.destfields:
            real_destfields.append(find_field(destfield, input.fields().names()))

        real_subdestfields = []
        for subdestfield in self.subdestfields:
            real_subdestfields.append(find_field(subdestfield, input.fields().names()))

        model_feedback = QgsProcessingMultiStepFeedback(2, feedback)

        if feedback.isCanceled():
            return {}

        print("dest_crs.isValid()", dest_crs.isValid())

        # print("self.types", self.types)
        # print("input_types", input_types)
        # print("input.fields()", input.fields())

        for input_type in input_types:
            input_field = find_field(self.types[input_type]["field"], input.fields().names())
            values = input.uniqueValues(input.fields().indexFromName(input_field))

            print("values", values)

            proc_result = processing.run(
                algOrName=self.extract_vertices,
                parameters={
                    extractVertices.INPUT: parameters[self.INPUT],
                    extractVertices.GROUPFIELDS: [input_field],
                    extractVertices.DESTFIELDS: real_destfields,
                    extractVertices.SUBDESTFIELDS: real_subdestfields,
                    extractVertices.CRS: dest_crs if dest_crs.isValid() else input.sourceCrs(),
                    extractVertices.SOLIDNUMBERING: solidnumbering,
                    extractVertices.GROUPSORT: groupsort,
                    extractVertices.FILTEREXPRESSION: filterexpression,
                    extractVertices.GROUPPOLYGONS: 'TEMPORARY_OUTPUT',
                    extractVertices.GROUPLINES: 'TEMPORARY_OUTPUT',
                    extractVertices.GROUPPOINTS: 'TEMPORARY_OUTPUT',
                    extractVertices.SECTIONS: 'TEMPORARY_OUTPUT',
                },
                context=context,
                feedback=model_feedback,
                is_child_algorithm=True
            )

            grouppoints: QgsVectorLayer = context.takeResultLayer(proc_result[extractVertices.GROUPPOINTS])
            sections: QgsVectorLayer = context.takeResultLayer(proc_result[extractVertices.SECTIONS])

            # print(grouppoints)
            # print(sections)

            # print(proc_result)

            for value in values:
                expression = QgsExpression().createFieldEqualityExpression(input_field, value)
                request = QgsFeatureRequest()
                request.setFlags(QgsFeatureRequest.NoGeometry)
                request.setFilterExpression(expression)

                # grouppoints.setSubsetString(expression)
                # print(grouppoints.featureCount())
                # sections.setSubsetString(expression)

                # grouppoints.getFeatures(request)
                # sections.getFeatures(request)

                grouppoints_temp = QgsVectorLayer("{}".format(QgsWkbTypes.displayString(grouppoints.wkbType())),
                                            "temporary_points", "memory")
                pr = grouppoints_temp.dataProvider()
                grouppoints_temp.startEditing()
                pr.addAttributes(grouppoints.fields())
                pr.addFeatures(grouppoints.getFeatures(request))
                grouppoints_temp.commitChanges()

                sections_temp = QgsVectorLayer("{}".format(QgsWkbTypes.displayString(sections.wkbType())),
                                                  "temporary_points", "memory")
                pr = sections_temp.dataProvider()
                sections_temp.startEditing()
                pr.addAttributes(sections.fields())
                pr.addFeatures(sections.getFeatures(request))
                sections_temp.commitChanges()

                # print(sections_temp.fields().names())
                # print(sections_temp.featureCount())
                # print(sections_temp.getFeature(0))

                dest_folder_prepared = prepare_path(dest_folder, self.__plugin_dir)

                if not os.path.isdir(dest_folder_prepared):
                    os.mkdir(dest_folder_prepared)

                processing.run(
                    algOrName=self.excel_creator,
                    parameters={
                        excelCreator.TEMPLATE: os.path.join(os.path.dirname(__file__),
                                                            "excel_templates", "Точки.xlsx"),
                        excelCreator.EXTRAPARAMS: ["crs",
                                                   dest_crs.description() if dest_crs.isValid() else input.sourceCrs().description()],
                        excelCreator.EXTRALAYERS: ["points", grouppoints_temp],
                        excelCreator.FILEOUTPUT: os.path.join(dest_folder_prepared, "Каталог координат {} - {}.xlsx".format(input_type, value)),
                    },
                    context=context,
                    feedback=model_feedback,
                    is_child_algorithm=True
                )

                # del grouppoints_temp

                processing.run(
                    algOrName=self.excel_creator,
                    parameters={
                        excelCreator.TEMPLATE: os.path.join(os.path.dirname(__file__),
                                                            "excel_templates", "Прохождение границ.xlsx"),
                        excelCreator.EXTRAPARAMS: [],
                        excelCreator.EXTRALAYERS: ["borders", sections_temp],
                        excelCreator.FILEOUTPUT: os.path.join(dest_folder_prepared, "Описание границ {} - {}.xlsx".format(input_type, value)),
                    },
                    context=context,
                    feedback=model_feedback,
                    is_child_algorithm=True
                )

                # del sections_temp

                # print("proc_result", proc_result)

                # print(grouppoints.featureCount(), sections.featureCount())

                # input.getFeatures(request)

                # materialized = input.materialize(request, feedback)

                # print(materialized.id())

        # for input_field in input_fields:
        #     input.uniqueValues(input.fields().indexFromName(input_field))

        return result

    def name(self) -> str:
        return 'create_report'

    def displayName(self) -> str:
        # return self.name()
        return 'Создать отчеты'

    def group(self) -> str:
        return 'Лесоустройство'

    def groupId(self) -> str:
        return 'LU'

    def createInstance(self) -> QgsProcessingAlgorithm:
        return createReport(self.__plugin_dir)

if __name__ == "__main__":
    QgsApplication.setPrefixPath(r'C:/OSGEO4~1/apps/qgis', True)
    qgs = QgsApplication([], False)
    qgs.initQgis()

    from processing.core.Processing import Processing
    from qgis.analysis import QgsNativeAlgorithms

    Processing.initialize()
    QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
    feedback = QgsProcessingFeedback()
    #
    # QgsExpressionContextUtils.globalScope()
    # QgsExpressionContextUtils.projectScope()

    context = QgsProcessingContext()
    context.setFeedback(feedback)
    context.setProject(QgsProject.instance())

    # processing.algorithmHelp()

    # parameters = {'DISSOLVE': True,
    #               'ERRORS': 'TEMPORARY_OUTPUT',
    #              'INPUT': 'd:/GoogleDrive/Разное/RLI/2019.12.02 - Бердову/Для Сергея/Бузулукское/Бузулукское сельское участковое_region.shp',
    #              'OUTPUT': 'TEMPORARY_OUTPUT',
    #              'SPECIES': 'C:/Users/seminozhenko.ss/PycharmProjects/okkh_plugin/resourses/species.xlsx|layername=species'}

    parameters = {
        'CRS': None,
        'FILTEREXPRESSION': '',
        'FOLDEROUTPUT': 'C:\\Users\\seminozhenko.ss\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\qlesinforg\\output',
        'GROUPSORT': 'y_max($geometry)',
        'INPUT': 'postgres://dbname=\'gis\' host=82.148.12.172 port=5432 user=\'qgis\' password=\'LvlgCuHAA\' key=\'id\' checkPrimaryKeyUnicity=\'1\' table=\"(SELECT id, sri, mu, gir, kv, zk, mk, skp, sknr, ST_MakeValid(geom) as geom FROM public.tax WHERE (sri = 49 AND mu = 9 AND gir = 2 AND kv = 93) OR (sri = 49 AND mu = 9 AND gir = 2 AND kv = 75) OR (sri = 49 AND mu = 9 AND gir = 2 AND kv = 92) OR (sri = 49 AND mu = 9 AND gir = 2 AND kv = 74) OR (sri = 49 AND mu = 9 AND gir = 1 AND kv = 131))\" (geom)',
        'SOLIDNUMBERING': False, 'TYPES': [0, 1, 2]
    }

    algr = createReport(r"C:\Users\seminozhenko.ss\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\qlesinforg")
    algr.initAlgorithm(None)
    result = algr.run(parameters, context, feedback)

    print(result)

    qgs.exitQgis()



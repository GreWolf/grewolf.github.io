__author__ = 'seminozhenko.ss'
__date__ = '2020-01-10'
__copyright__ = '(C) 2020 by seminozhenko.ss'

__revision__ = '$Format:%H$'

import json
import os
from typing import Dict, Any, List

import processing
from processing.modeler.ModelerDialog import ModelerDialog
from qgis.PyQt.QtCore import (
    QCoreApplication, QT_TR_NOOP
)
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingUtils,
                       QgsCoordinateReferenceSystem,
                       QgsExpression,
                       QgsProcessingParameterExpression,
                       QgsProcessingParameterBoolean,
                       QgsProcessingException,
                       QgsWkbTypes,
                       QgsProcessingParameterDefinition,
                       QgsProcessingParameterField,
                       QgsProcessingParameterString,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingFeedback,
                       QgsProcessingContext,
                       QgsProject,
                       QgsApplication, QgsProcessingFeatureSource, QgsProcessingParameterCrs,
                       QgsProcessingParameterFileDestination, QgsVectorLayer
                       )

# from processing.modeler.ModelerDialog import ModelerDialog
# import processing

from ...modules.optionParser import parseOptions
from ...models.dissolverModel import dissolverModel

# ------------------ only for stand-alone testing

# from modules.checker import Checker
# from modules.checkerFunctions import checkerFunc
# # from ...modules.grouper import Grouper
# from modules.grouperSciPy import Grouper
# from modules.optionParser import parseOptions
# from modules.preparer import Preparer
# from modules.proximity import proximity
# from modules.resulter import Resulter
# from modules.species import Species
# from widgets.expression import getCustomExpressionWrapper
# from widgets.infields import getInFieldsWidgetWrapper, ParameterInFields
# from widgets.outfields import getOutFieldsWidgetWrapper, ParameterOutFields
# from models.PreparePoint import PreparePointModel

# ------------------ only for stand-alone testing


options = parseOptions(__file__)

class extractVertices(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    GROUPFIELDS = "GROUPFIELDS"
    GROUPFIELD = "GROUPFIELD"
    DESTFIELDS = "DESTFIELDS"
    SUBDESTFIELDS = "SUBDESTFIELDS"
    POINTFIELD = "POINTFIELD"
    PARCELFIELD = "PARCELFIELD"
    SOLIDNUMBERING = "SOLIDNUMBERING"
    GROUPSORT = "GROUPSORT"
    GROUPPOLYGONS = "GROUPPOLYGONS"
    GROUPPOINTS = "GROUPPOINTS"
    CRS = "CRS"
    FILTEREXPRESSION = 'FILTEREXPRESSION'
    FILEOUTPUT = "FILEOUTPUT"

    def __init__(self, plugin_dir):
        self.__plugin_dir = plugin_dir

        super().__init__()

    def initAlgorithm(self, config: Dict[str, Any]):
        self.addParameter(QgsProcessingParameterFeatureSource(
            name=self.INPUT,
            description='Входной слой',
            types=[QgsProcessing.TypeVectorAnyGeometry],
            defaultValue=None
        ))

        self.addParameter(QgsProcessingParameterField(
            name=self.GROUPFIELDS,
            description='Поля по которым нужно сгруппировать полигоны',
            defaultValue=options.get('GROUPFIELDS', None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Any,
            allowMultiple=True,
            optional=False
        ))

        self.addParameter(QgsProcessingParameterField(
            name=self.DESTFIELDS,
            description='Поля, информация о которых должна быть сохранена в точках',
            defaultValue=options.get('DESTFIELDS', None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Any,
            allowMultiple=True,
            optional=False
        ))

        # TODO придумать нормальное описание для параметров

        self.addParameter(QgsProcessingParameterField(
            name=self.SUBDESTFIELDS,
            description='Поля, информация о которых должна быть сохранена в точках 2',
            defaultValue=options.get('SUBDESTFIELDS', None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            allowMultiple=True,
            optional=True
        ))

        self.addParameter(QgsProcessingParameterString(
            name=self.GROUPFIELD,
            description='Имя для поля номера полигона',
            defaultValue=options.get('GROUPFIELD', None),
            multiLine=False,
            optional=False
        ))

        self.addParameter(QgsProcessingParameterString(
            name=self.POINTFIELD,
            description='Имя поля для номера точки',
            defaultValue=options.get('POINTFIELD', None),
            multiLine=False,
            optional=False
        ))

        self.addParameter(QgsProcessingParameterString(
            name=self.PARCELFIELD,
            description='Имя поля для номера единицы группировки',
            defaultValue=options.get('PARCELFIELD', None),
            multiLine=False,
            optional=False
        ))

        param = QgsProcessingParameterCrs(
            name=self.CRS,
            description='Проекция в которой необходимо посчитать координаты точек',
            optional=True,
            defaultValue=options.get('CRS', None)
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterBoolean(
            name=self.SOLIDNUMBERING,
            description='Сплошная нумерация точек',
            defaultValue=options.get('SOLIDNUMBERING', None)
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterExpression(
            name=self.FILTEREXPRESSION,
            description='Выражение для предварительной фильтрации вектора',
            parentLayerParameterName=self.INPUT,
            defaultValue=options.get('FILTEREXPRESSION', None),
            optional=True
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterExpression(
            name=self.GROUPSORT,
            description='Выражение по которому будет присваиваться номер полигону',
            parentLayerParameterName=self.INPUT,
            defaultValue=options.get('GROUPSORT', None),
            optional=True
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        self.addParameter(QgsProcessingParameterFeatureSink(
            name=self.GROUPPOLYGONS,
            description='Сгруппированные полигоны',
            type=QgsProcessing.TypeVectorAnyGeometry,
            createByDefault=False,
            supportsAppend=True,
            defaultValue=None))

        self.addParameter(QgsProcessingParameterFeatureSink(
            name=self.GROUPPOINTS,
            description='Точки границ сгруппированных полигонов',
            type=QgsProcessing.TypeVectorAnyGeometry,
            createByDefault=True,
            supportsAppend=True,
            defaultValue='TEMPORARY_OUTPUT'))

        # self.addParameter(QgsProcessingParameterFileDestination(
        #     name=self.FILEOUTPUT,
        #     description="Файл с точками",
        #     fileFilter="*.xlsx"
        # ))

    def processAlgorithm(self, parameters: Dict[str, Any],
                         context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):
        result = dict()

        # если поле (с optional=True) было оставлено пустым, то parameterAs выдает
        # значение по умолчанию, что в данном случае не нужно. Обрабатываем этот случай вручную

        input: QgsProcessingFeatureSource = self.parameterAsSource(parameters, self.INPUT, context)
        groupfields: List[str] = self.parameterAsFields(parameters, self.GROUPFIELDS, context)
        destfields: List[str] = self.parameterAsFields(parameters, self.DESTFIELDS, context)

        if parameters[self.SUBDESTFIELDS]:
            subdestfields: List[str] = self.parameterAsFields(parameters, self.SUBDESTFIELDS, context)
        else:
            subdestfields = []

        groupfield: str = self.parameterAsString(parameters, self.GROUPFIELD, context)
        pointfield: str = self.parameterAsString(parameters, self.POINTFIELD, context)
        parcelfield: str = self.parameterAsString(parameters, self.PARCELFIELD, context)

        solidnumbering: bool = self.parameterAsBool(parameters, self.SOLIDNUMBERING, context)

        if parameters[self.GROUPSORT]:
            groupsort: str = self.parameterAsExpression(parameters, self.GROUPSORT, context)
        else:
            groupsort = ""

        if parameters[self.FILTEREXPRESSION]:
            filterexpression: str = self.parameterAsExpression(parameters, self.FILTEREXPRESSION, context)
        else:
            filterexpression = ""

        if parameters[self.CRS]:
            dest_crs: QgsCoordinateReferenceSystem = self.parameterAsCrs(parameters, self.CRS, context)
        else:
            dest_crs = QgsCoordinateReferenceSystem()

        # fileoutput: str = self.parameterAsFileOutput(parameters, self.FILEOUTPUT, context)

        # print("input", input)
        # print("groupfields", groupfields)
        # print("destfields", destfields)
        # print("subdestfields", subdestfields)
        # print("groupfield", groupfield)
        # print("pointfield", pointfield)
        # print("parcelfield", parcelfield)
        # print("solidnumbering", solidnumbering)
        # print("groupsort", groupsort)
        # print("filterexpression", filterexpression)
        # print("dest_crs", dest_crs)

        self.__dlg = ModelerDialog()
        self.__dlg.loadModel(os.path.join(self.__plugin_dir, r"qgis_models", "extract_vertices.model3"))

        proc_result = processing.run(self.__dlg.model(),
                                     {
                                         'input': parameters[self.INPUT],
                                         'GROUPFIELDS': groupfields,
                                         'GROUPFIELD': groupfield,
                                         'DESTFIELDS': destfields,
                                         'SUBDESTFIELDS': subdestfields,
                                         'POINTFIELD': pointfield,
                                         'PARCELFIELD': parcelfield,
                                         'SOLIDNUMBERING': solidnumbering,
                                         'GROUPSORT': groupsort,
                                         'DELFIELDS': input.fields().names(),
                                         'CRS': dest_crs if dest_crs.isValid() else input.sourceCrs(),
                                         'FILTEREXPRESSION': filterexpression,
                                         'qgis:deletecolumn_1:GROUPPOLYGONS': 'TEMPORARY_OUTPUT',
                                         'native:orderbyexpression_2:RESULT2': 'TEMPORARY_OUTPUT'
                                     }, context=context, feedback=feedback, is_child_algorithm=True)

        temppoligons = QgsProcessingUtils.mapLayerFromString(proc_result['qgis:deletecolumn_1:GROUPPOLYGONS'], context)
        temppoints = QgsProcessingUtils.mapLayerFromString(proc_result['native:orderbyexpression_2:RESULT2'], context)

        (points, points_id) = self.parameterAsSink(parameters, self.GROUPPOINTS, context, temppoints.fields(),
                                                   QgsWkbTypes.multiType(temppoints.wkbType()),
                                                   temppoints.sourceCrs())

        (polygons, polygons_id) = self.parameterAsSink(parameters, self.GROUPPOLYGONS, context, temppoligons.fields(),
                                                       QgsWkbTypes.multiType(temppoligons.wkbType()),
                                                       temppoligons.sourceCrs())

        points.addFeatures(temppoints.getFeatures())
        polygons.addFeatures(temppoligons.getFeatures())

        result.update({self.GROUPPOINTS: points_id, self.GROUPPOLYGONS: polygons_id})

        return result

        # # pointfieldname = 'point_id'
        # # uchfieldname = 'uch_id'
        # linkidfieldname = 'link_id'
        #
        # xyfieldsnames = ['x', 'y']
        # varticesfieldsnames = ['vertex_index', 'vertex_part', 'vertex_part_ring', 'vertex_part_index', 'distance',
        #                        'angle']
        #
        # preparepoint = dissolverModel()
        # preparepoint.initAlgorithm(None)
        #
        # infields = input.fields()
        # infieldsnames = infields.names()
        # nongroupfieldsnames = list(set(infieldsnames) - set(groupfields))
        #
        # inputcrs = input.sourceCrs()
        # fieldsfordelduplicates = groupfields + xyfieldsnames
        # sortexpression = " || ' ' || ".join(['"{}"'.format(fieldname) for fieldname in groupfields])
        # linkexpression = " || ' ' || ".join(['"{}"'.format(fieldname) for fieldname in fieldsfordelduplicates])
        # dropfieldsmk = nongroupfieldsnames + ['temp_id']
        # dropfieldskvmk = ["{}_2".format(i) for i in
        #                   groupfields + varticesfieldsnames + xyfieldsnames + [linkidfieldname]] + [
        #                      linkidfieldname] + varticesfieldsnames
        #
        # modelprameters = {'POINTFIELD': pointfieldname,
        #                   'UCHFIELD': uchfieldname,
        #                   'DROPFIELDSKVMK': dropfieldskvmk,
        #                   'GROUPFIELDS': groupfields,
        #                   'FIELDSFORDELDUPLICATES': fieldsfordelduplicates,
        #                   'INPUT': parameters[self.INPUT],
        #                   'DROPFIELDSMK': dropfieldsmk,
        #                   'LINKEXPRESSION': linkexpression,
        #                   'PROJECTION': inputcrs,
        #                   'SORTEXPRESSION': sortexpression,
        #                   'POLYGONS': 'TEMPORARY_OUTPUT',
        #                   'POINTS': 'TEMPORARY_OUTPUT'}
        #
        # modelprameters = {'AREAS': 'TEMPORARY_OUTPUT',
        #                   'POINTFIELD': 'point_id',
        #                   'POINTS': 'TEMPORARY_OUTPUT',
        #                   'UCHFIELD': 'uch_id',
        #                   'DROPFIELDSKVMK': ['Sri_2', 'Mu_2', 'Gir_2', 'Mk_2', 'vertex_index_2', 'vertex_part_2',
        #                                      'vertex_part_ring_2', 'vertex_part_index_2', 'distance_2', 'angle_2',
        #                                      'x_2', 'y_2', 'link_id_2', 'link_id', 'vertex_index', 'vertex_part',
        #                                      'vertex_part_ring', 'vertex_part_index', 'distance', 'angle'],
        #                   'GROUPFIELDS': ['Sri', 'Mu', 'Gir', 'Mk'],
        #                   'FIELDSFORDELDUPLICATES': ['Sri', 'Mu', 'Gir', 'Mk', 'x', 'y'],
        #                   'INPUT': 'd:/GoogleDrive/Разное/RLI/2019.12.02 - Бердову/ГОК/ВД.shp',
        #                   'DROPFIELDSMK': ['Kv', 'OBJECTID', 'fid_1', 'Lr', 'Zkz', 'Ugir', 'Mu1', 'Rel', 'Sknr', 'Pl',
        #                                    'Zk', 'Vmr', 'Amz1', 'Akl', 'Agr', 'Bon', 'Mtip', 'Dtg', 'Skal1', 'Tur1h1',
        #                                    'Kl', 'Strata', 'Izm', 'layer', 'Deleted', 'Ð__Ð__Ð___', 'Shape_Leng',
        #                                    'Shape_Area'],
        #                   'LINKEXPRESSION': '\"Sri\" || \' \' || \"Mu\" || \' \' || \"Gir\" || \' \' || \"Mk\" || \' \' || \"x\" || \' \' || \"y\" ',
        #                   'PROJECTION': QgsCoordinateReferenceSystem('EPSG:4326'),
        #                   'SORTEXPRESSIONKV': '\"Sri\" || \' \' || \"Mu\" || \' \' || \"Gir\" || \' \' || \"Mk\"',
        #                   'SORTEXPRESSIONMK': 'y_max($geometry)'}
        #
        # modelresult = preparepoint.run(modelprameters, context, feedback)
        #
        # # dlg = ModelerDialog()
        # # dlg.loadModel(r"C:\Users\seminozhenko.ss\PycharmProjects\seminozhenko\models\PreparePoint.model3")
        # # processing.runAndLoadResults(dlg.model, modelprameters)
        #
        # temppointlayer = QgsProcessingUtils.mapLayerFromString(modelresult[0]["POINTS"], context)
        # temppolygonlayer = QgsProcessingUtils.mapLayerFromString(modelresult[0]["POLYGONS"], context)
        #
        # # result.update({self.OUTPUT: modelresult[0]['POINTS']})
        # #
        # # (output, output_id) = self.parameterAsSink(parameters, self.OUTPUT, context, input.fields(),
        # #                                            QgsWkbTypes.multiType(input.wkbType()), inputcrs)
        #
        # (points, points_id) = self.parameterAsSink(parameters, self.POINTS, context, temppointlayer.fields(),
        #                                            QgsWkbTypes.multiType(temppointlayer.wkbType()),
        #                                            temppointlayer.sourceCrs())
        #
        # (polygons, polygons_id) = self.parameterAsSink(parameters, self.POLYGONS, context, temppolygonlayer.fields(),
        #                                                QgsWkbTypes.multiType(temppolygonlayer.wkbType()),
        #                                                temppolygonlayer.sourceCrs())
        #
        # points.addFeatures(temppointlayer.getFeatures())
        # polygons.addFeatures(temppolygonlayer.getFeatures())
        #
        # result.update({self.POINTS: points_id, self.POLYGONS: polygons_id})
        #
        # return result

    def name(self) -> str:
        return 'exctract_vertices'

    def displayName(self) -> str:
        # return self.name()
        return 'Извлечение точек для описания границ'

    def group(self) -> str:
        return 'Общие инструменты'

    def groupId(self) -> str:
        return 'LU'

    #
    # def tr(self, string):
    #     return QCoreApplication.translate('tgdAlgorithm', string)
    #
    # def tr2(self, string):
    #     return QCoreApplication.translate('@default', string)

    def createInstance(self) -> QgsProcessingAlgorithm:
        return extractVertices(self.__plugin_dir)


if __name__ == "__main__":
    QgsApplication.setPrefixPath(r'C:/OSGEO4~1/apps/qgis', True)
    qgs = QgsApplication([], False)
    qgs.initQgis()

    import processing
    from processing.core.Processing import Processing
    from qgis.analysis import QgsNativeAlgorithms

    Processing.initialize()
    QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
    feedback = QgsProcessingFeedback()
    context = QgsProcessingContext()
    context.setFeedback(feedback)
    context.setProject(QgsProject.instance())

    # processing.algorithmHelp()

    # parameters = {'DISSOLVE': True,
    #               'ERRORS': 'TEMPORARY_OUTPUT',
    #              'INPUT': 'd:/GoogleDrive/Разное/RLI/2019.12.02 - Бердову/Для Сергея/Бузулукское/Бузулукское сельское участковое_region.shp',
    #              'OUTPUT': 'TEMPORARY_OUTPUT',
    #              'SPECIES': 'C:/Users/seminozhenko.ss/PycharmProjects/okkh_plugin/resourses/species.xlsx|layername=species'}

    parameters = {'GROUPINFIELDS': ['Sri', 'Mu', 'Gir', 'Mk'],
                  'INPUT': 'd:/GoogleDrive/Разное/RLI/2019.12.02 - Бердову/ГОК/ВД.shp'}

    algr = extractVertices()
    algr.initAlgorithm(None)
    result = algr.run(parameters, context, feedback)

    print(result)

    qgs.exitQgis()

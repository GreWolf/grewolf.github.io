__author__ = 'seminozhenko.ss'
__date__ = '2020-01-10'
__copyright__ = '(C) 2020 by seminozhenko.ss'

__revision__ = '$Format:%H$'

import os
from typing import Dict, Any, List

from processing.modeler.ModelerDialog import ModelerDialog
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingUtils,
                       QgsCoordinateReferenceSystem,
                       QgsProcessingParameterExpression,
                       QgsProcessingParameterBoolean,
                       QgsWkbTypes,
                       QgsProcessingParameterDefinition,
                       QgsProcessingParameterField,
                       QgsProcessingParameterString,
                       QgsProcessingFeedback,
                       QgsProcessingContext,
                       QgsProject,
                       QgsApplication, QgsProcessingFeatureSource, QgsProcessingParameterCrs,
                       QgsProcessingMultiStepFeedback
                       )

from ...widgets.expression_widget import CustomExpressionWrapper
from ...widgets.field_widget import CustomFieldWrapper
from ...modules.optionParser import parseOptions

from ..compose_vertices.compose_vertices import composeVertices

# эти два импорта не удалять
import processing
from processing.core.Processing import Processing

# from processing.modeler.ModelerDialog import ModelerDialog


# ------------------ only for stand-alone testing

# from modules.checker import Checker
# from modules.checkerFunctions import checkerFunc
# # from ...modules.grouper import Grouper
# from modules.grouperSciPy import Grouper
# from modules.optionParser import parseOptions
# from modules.preparer import Preparer
# from modules.proximity import proximity
# from modules.resulter import Resulter
# from modules.species import Species
# from widgets.expression import getCustomExpressionWrapper
# from widgets.infields import getInFieldsWidgetWrapper, ParameterInFields
# from widgets.outfields import getOutFieldsWidgetWrapper, ParameterOutFields
# from models.PreparePoint import PreparePointModel

# ------------------ only for stand-alone testing


options = parseOptions(__file__)


class extractVertices(QgsProcessingAlgorithm):
    INPUT = 'INPUT' #
    GROUPFIELDS = "GROUPFIELDS" #
    GROUPFIELD = "GROUPFIELD" #
    DESTFIELDS = "DESTFIELDS" #
    SUBDESTFIELDS = "SUBDESTFIELDS" #
    POINTFIELD = "POINTFIELD" #
    SECTIONFIELD = "SECTIONFIELD" #
    CRS = "CRS" #
    FILTEREXPRESSION = 'FILTEREXPRESSION' #
    LINEGROUPFIELD = "LINEGROUPFIELD" #
    SUBSECTIONFIELD = "SUBSECTIONFIELD" #

    POINTGROUPMETHOD = 'POINTGROUPMETHOD'
    LINESBYROWS = 'LINESBYROWS'
    LINEGROUPMETHOD = 'LINEGROUPMETHOD'
    GROUPGROUPMETHOD = 'GROUPGROUPMETHOD'
    GROUPSPATIALSORT = "GROUPSPATIALSORT"

    #
    # SOLIDNUMBERING = "SOLIDNUMBERING"
    # GROUPSORT = "GROUPSORT"
    #
    # SOLIDGROUPNUMBERING = "SOLIDGROUPNUMBERING"
    #
    # FILEOUTPUT = "FILEOUTPUT"

    GROUPEDFIELD = "GROUPEDFIELD" #

    GROUPLINES = "GROUPLINES" #
    GROUPPOLYGONS = "GROUPPOLYGONS" #
    GROUPPOINTS = "GROUPPOINTS" #
    SECTIONS = "SECTIONS" #

    def __init__(self, plugin_dir):
        self.__plugin_dir = plugin_dir
        self.compose_vertices = composeVertices(self.__plugin_dir)

        super().__init__()

    def initAlgorithm(self, config: Dict[str, Any]):

        # print(config)

        # не уверен правильно ли инициализировать дочерний алгоритм в initAlgorithm
        # и нужно ли делать compose_vertices.initAlgorithm(config)
        self.compose_vertices.initAlgorithm(config)

        self.addParameter(QgsProcessingParameterFeatureSource(
            name=self.INPUT,
            description='Входной слой',
            types=[QgsProcessing.TypeVectorPolygon],
            defaultValue=None
        ))

        self.addParameter(QgsProcessingParameterField(
            name=self.GROUPFIELDS,
            description='Поля по которым нужно сгруппировать полигоны',
            defaultValue=options.get(self.GROUPFIELDS, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Any,
            allowMultiple=True,
            optional=False
        ))

        self.parameterDefinition(self.GROUPFIELDS).setMetadata({
            'widget_wrapper': CustomFieldWrapper
        })

        self.addParameter(QgsProcessingParameterField(
            name=self.DESTFIELDS,
            description='Поля, информация о которых должна быть сохранена в точках',
            defaultValue=options.get(self.DESTFIELDS, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Any,
            allowMultiple=True,
            optional=False
        ))

        self.parameterDefinition(self.DESTFIELDS).setMetadata({
            'widget_wrapper': CustomFieldWrapper
        })

        # TODO придумать нормальное описание для параметров

        self.addParameter(QgsProcessingParameterField(
            name=self.SUBDESTFIELDS,
            description='Поля, информация о которых должна быть сохранена в точках 2',
            defaultValue=options.get(self.SUBDESTFIELDS, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            allowMultiple=True,
            optional=True
        ))

        self.parameterDefinition(self.SUBDESTFIELDS).setMetadata({
            'widget_wrapper': CustomFieldWrapper
        })

        param = QgsProcessingParameterString(
            name=self.GROUPFIELD,
            description='Имя для поля номера полигона',
            defaultValue=options.get(self.GROUPFIELD, None),
            multiLine=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterString(
            name=self.LINEGROUPFIELD,
            description='Имя для поля номера линии в полигоне',
            defaultValue=options.get(self.LINEGROUPFIELD, None),
            multiLine=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterString(
            name=self.POINTFIELD,
            description='Имя поля для номера точки',
            defaultValue=options.get(self.POINTFIELD, None),
            multiLine=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterString(
            name=self.SECTIONFIELD,
            description='Имя поля для номера единицы группировки',
            defaultValue=options.get(self.SECTIONFIELD, None),
            multiLine=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterString(
            name=self.SUBSECTIONFIELD,
            description='Имя поля для единицы группировки 2',
            defaultValue=options.get(self.SUBSECTIONFIELD, None),
            multiLine=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterString(
            name=self.GROUPEDFIELD,
            description='Имя поля в котором буду сгруппированные значения',
            defaultValue=options.get(self.GROUPEDFIELD, None),
            multiLine=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        self.addParameter(QgsProcessingParameterCrs(
            name=self.CRS,
            description='Проекция в которой необходимо посчитать координаты точек',
            optional=True,
            defaultValue=options.get(self.CRS, None)
        ))

        # param = QgsProcessingParameterBoolean(
        #     name=self.SOLIDNUMBERING,
        #     description='Сплошная нумерация точек',
        #     defaultValue=options.get(self.SOLIDNUMBERING, None)
        # )
        # param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        # self.addParameter(param)

        # param = QgsProcessingParameterBoolean(
        #     name=self.SOLIDGROUPNUMBERING,
        #     description='Сплошная нумерация полигонов',
        #     defaultValue=options.get(self.SOLIDGROUPNUMBERING, None)
        # )
        # param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        # self.addParameter(param)

        self.addParameter(QgsProcessingParameterExpression(
            name=self.FILTEREXPRESSION,
            description='Выражение для предварительной фильтрации вектора',
            parentLayerParameterName=self.INPUT,
            defaultValue=options.get(self.FILTEREXPRESSION, ""),
            optional=True
        ))

        self.parameterDefinition(self.FILTEREXPRESSION).setMetadata({
            'widget_wrapper': CustomExpressionWrapper
        })

        # param = QgsProcessingParameterExpression(
        #     name=self.GROUPSORT,
        #     description='Выражение по которому будет присваиваться номер полигону',
        #     parentLayerParameterName=self.INPUT,
        #     defaultValue=options.get(self.GROUPSORT, None),
        #     optional=True
        # )
        # param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        # self.addParameter(param)
        #
        # self.parameterDefinition(self.GROUPSORT).setMetadata({
        #     'widget_wrapper': CustomExpressionWrapper
        # })

        self.addParameter(QgsProcessingParameterFeatureSink(
            name=self.GROUPPOLYGONS,
            description='Сгруппированные полигоны',
            type=QgsProcessing.TypeVectorAnyGeometry,
            createByDefault=False,
            supportsAppend=True,
            defaultValue=None))

        self.addParameter(QgsProcessingParameterFeatureSink(
            name=self.GROUPLINES,
            description='Линии сгруппированных полигонов',
            type=QgsProcessing.TypeVectorAnyGeometry,
            createByDefault=False,
            supportsAppend=True,
            defaultValue=None))

        self.addParameter(QgsProcessingParameterFeatureSink(
            name=self.GROUPPOINTS,
            description='Точки границ сгруппированных полигонов',
            type=QgsProcessing.TypeVectorAnyGeometry,
            createByDefault=True,
            supportsAppend=True,
            defaultValue='TEMPORARY_OUTPUT'))

        self.addParameter(QgsProcessingParameterFeatureSink(
            name=self.SECTIONS,
            description='Описание границ',
            type=QgsProcessing.TypeVectorAnyGeometry,
            createByDefault=True,
            supportsAppend=True,
            defaultValue='TEMPORARY_OUTPUT'))

        # self.addParameter(QgsProcessingParameterFileDestination(
        #     name=self.FILEOUTPUT,
        #     description="Файл с точками",
        #     fileFilter="*.xlsx"
        # ))

    def processAlgorithm(self, parameters: Dict[str, Any],
                         context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):
        result = dict()

        input: QgsProcessingFeatureSource = self.parameterAsSource(parameters, self.INPUT, context)
        groupfields: List[str] = self.parameterAsFields(parameters, self.GROUPFIELDS, context)
        destfields: List[str] = self.parameterAsFields(parameters, self.DESTFIELDS, context)

        # если поле (с optional=True) было оставлено пустым, то parameterAs... выдает
        # значение по умолчанию, что в данном случае не нужно. Обрабатываем этот случай вручную
        if parameters[self.SUBDESTFIELDS]:
            subdestfields: List[str] = self.parameterAsFields(parameters, self.SUBDESTFIELDS, context)
        else:
            subdestfields = []

        groupfield: str = self.parameterAsString(parameters, self.GROUPFIELD, context)
        pointfield: str = self.parameterAsString(parameters, self.POINTFIELD, context)
        sectionfield: str = self.parameterAsString(parameters, self.SECTIONFIELD, context)
        subsectionfield: str = self.parameterAsString(parameters, self.SUBSECTIONFIELD, context)
        linegroupfield: str = self.parameterAsString(parameters, self.LINEGROUPFIELD, context)
        groupedfield: str = self.parameterAsString(parameters, self.GROUPEDFIELD, context)

        solidnumbering: bool = self.parameterAsBool(parameters, self.SOLIDNUMBERING, context)
        solidgroupnumbering: bool = self.parameterAsBool(parameters, self.SOLIDGROUPNUMBERING, context)

        if parameters[self.GROUPSORT]:
            groupsort: str = self.parameterAsExpression(parameters, self.GROUPSORT, context)
        else:
            groupsort = ""

        if parameters[self.FILTEREXPRESSION]:
            filterexpression: str = self.parameterAsExpression(parameters, self.FILTEREXPRESSION, context)
        else:
            filterexpression = ""

        if parameters[self.CRS]:
            dest_crs: QgsCoordinateReferenceSystem = self.parameterAsCrs(parameters, self.CRS, context)
        else:
            dest_crs = QgsCoordinateReferenceSystem()

        # говорим алгоритму, что он будет состоять из двух шагов
        model_feedback = QgsProcessingMultiStepFeedback(2, feedback)
        # проверяем не отменил ли пользователь выполнение
        if feedback.isCanceled():
            return {}

        print("parameters", parameters)

        # загрузка модели из файла
        self.__dlg = ModelerDialog()
        self.__dlg.loadModel(os.path.join(self.__plugin_dir, r"qgis_models", "extract_vertices2.model3"))

        # запуск модели, загруженной из файла
        proc_result = processing.run(self.__dlg.model(),
                                     {
                                         self.INPUT: parameters[self.INPUT],
                                         self.GROUPFIELDS: groupfields,
                                         self.DESTFIELDS: destfields,
                                         self.SUBDESTFIELDS: subdestfields,
                                         self.GROUPFIELD: groupfield,
                                         self.LINEGROUPFIELD: linegroupfield,
                                         self.POINTFIELD: pointfield,
                                         self.SECTIONFIELD: sectionfield,
                                         self.SUBSECTIONFIELD: subsectionfield,
                                         self.SOLIDGROUPNUMBERING: solidgroupnumbering,
                                         self.CRS: dest_crs if dest_crs.isValid() else input.sourceCrs(),
                                         self.SOLIDNUMBERING: solidnumbering,
                                         self.GROUPSORT: groupsort,
                                         'DELFIELDS': input.fields().names(),
                                         self.FILTEREXPRESSION: filterexpression,
                                         'native:deletecolumn_1:{}'.format(
                                             self.GROUPPOLYGONS): 'TEMPORARY_OUTPUT',
                                         'native:addautoincrementalfield_7:{}'.format(
                                             self.GROUPLINES): 'TEMPORARY_OUTPUT',
                                         'native:orderbyexpression_2:{}'.format(
                                             self.GROUPPOINTS): 'TEMPORARY_OUTPUT'
                                     }, context=context, feedback=model_feedback, is_child_algorithm=True)

        model_feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # algr = composeVertices(self.__plugin_dir)
        # algr.initAlgorithm(None)

        sections_temp_id = processing.run(
            # algOrName=composeVertices(self.__plugin_dir),
            algOrName=self.compose_vertices,
            parameters={
                composeVertices.INPUT: proc_result['native:orderbyexpression_2:{}'.format(self.GROUPPOINTS)],
                composeVertices.DESTFIELDS: destfields,
                composeVertices.SUBDESTFIELDS: subdestfields,
                composeVertices.GROUPFIELDS: groupfields,
                composeVertices.GROUPFIELD: groupfield,
                composeVertices.POINTFIELD: pointfield,
                composeVertices.SECTIONFIELD: sectionfield,
                composeVertices.SUBSECTIONFIELD: subsectionfield,
                composeVertices.GROUPEDFIELD: groupedfield,
                composeVertices.SECTIONS: 'TEMPORARY_OUTPUT'
            },
            context=context,
            feedback=model_feedback,
            is_child_algorithm=True
        )[composeVertices.SECTIONS]

        # print("запускаем")
        # sections_temp_id = composeVertices(self.__plugin_dir).run(parameters={
        #     composeVertices.INPUT: proc_result['native:orderbyexpression_2:{}'.format(self.GROUPPOINTS)],
        #     composeVertices.DESTFIELDS: destfields,
        #     composeVertices.SUBDESTFIELDS: subdestfields,
        #     composeVertices.GROUPFIELDS: groupfields,
        #     composeVertices.GROUPFIELD: groupfield,
        #     composeVertices.POINTFIELD: pointfield,
        #     composeVertices.SECTIONFIELD: sectionfield,
        #     composeVertices.SUBSECTIONFIELD: subsectionfield,
        #     composeVertices.GROUPEDFIELD: groupedfield,
        #     composeVertices.SECTIONS: 'TEMPORARY_OUTPUT'
        # },
        #     context=context,
        #     feedback=model_feedback)[0][composeVertices.SECTIONS]

        model_feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # print(sections_temp_id)

        # print("запустили")

        # context.takeResultLayer()

        temppoligons = QgsProcessingUtils.mapLayerFromString(
            proc_result['native:deletecolumn_1:{}'.format(self.GROUPPOLYGONS)], context)
        templines = QgsProcessingUtils.mapLayerFromString(
            proc_result['native:addautoincrementalfield_7:{}'.format(self.GROUPLINES)], context)
        temppoints = QgsProcessingUtils.mapLayerFromString(
            proc_result['native:orderbyexpression_2:{}'.format(self.GROUPPOINTS)], context)
        tempsections = QgsProcessingUtils.mapLayerFromString(sections_temp_id, context)

        (points, points_id) = self.parameterAsSink(parameters, self.GROUPPOINTS, context, temppoints.fields(),
                                                   QgsWkbTypes.multiType(temppoints.wkbType()),
                                                   temppoints.sourceCrs())

        (polygons, polygons_id) = self.parameterAsSink(parameters, self.GROUPPOLYGONS, context, temppoligons.fields(),
                                                       QgsWkbTypes.multiType(temppoligons.wkbType()),
                                                       temppoligons.sourceCrs())

        (lines, lines_id) = self.parameterAsSink(parameters, self.GROUPLINES, context, templines.fields(),
                                                 QgsWkbTypes.multiType(templines.wkbType()),
                                                 templines.sourceCrs())

        (sections, sections_id) = self.parameterAsSink(parameters, self.SECTIONS, context, tempsections.fields(),
                                                       QgsWkbTypes.multiType(tempsections.wkbType()),
                                                       tempsections.sourceCrs())

        points.addFeatures(temppoints.getFeatures())
        polygons.addFeatures(temppoligons.getFeatures())
        lines.addFeatures(templines.getFeatures())
        sections.addFeatures(tempsections.getFeatures())

        result.update({self.GROUPPOINTS: points_id,
                       self.GROUPPOLYGONS: polygons_id,
                       self.GROUPLINES: lines_id,
                       self.SECTIONS: sections_id})

        return result

    def name(self) -> str:
        return 'exctract_vertices'

    def displayName(self) -> str:
        # return self.name()
        return 'Извлечение точек для описания границ'

    def group(self) -> str:
        return 'Лесоустройство'

    def groupId(self) -> str:
        return 'LU'

    #
    # def tr(self, string):
    #     return QCoreApplication.translate('tgdAlgorithm', string)
    #
    # def tr2(self, string):
    #     return QCoreApplication.translate('@default', string)

    def createInstance(self) -> QgsProcessingAlgorithm:
        return extractVertices(self.__plugin_dir)


if __name__ == "__main__":
    QgsApplication.setPrefixPath(r'C:/OSGEO4~1/apps/qgis', True)
    qgs = QgsApplication([], False)
    qgs.initQgis()

    import processing
    from processing.core.Processing import Processing
    from qgis.analysis import QgsNativeAlgorithms

    processing.run()

    Processing.initialize()
    QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
    feedback = QgsProcessingFeedback()
    context = QgsProcessingContext()
    context.setFeedback(feedback)
    context.setProject(QgsProject.instance())

    # processing.algorithmHelp()

    # parameters = {'DISSOLVE': True,
    #               'ERRORS': 'TEMPORARY_OUTPUT',
    #              'INPUT': 'd:/GoogleDrive/Разное/RLI/2019.12.02 - Бердову/Для Сергея/Бузулукское/Бузулукское сельское участковое_region.shp',
    #              'OUTPUT': 'TEMPORARY_OUTPUT',
    #              'SPECIES': 'C:/Users/seminozhenko.ss/PycharmProjects/okkh_plugin/resourses/species.xlsx|layername=species'}

    parameters = {'GROUPINFIELDS': ['Sri', 'Mu', 'Gir', 'Mk'],
                  'INPUT': 'd:/GoogleDrive/Разное/RLI/2019.12.02 - Бердову/ГОК/ВД.shp'}

    algr = extractVertices()
    algr.initAlgorithm(None)
    result = algr.run(parameters, context, feedback)

    print(result)

    qgs.exitQgis()

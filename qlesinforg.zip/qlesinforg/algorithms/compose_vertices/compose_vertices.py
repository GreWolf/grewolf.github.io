__author__ = 'seminozhenko.ss'
__date__ = '2020-01-10'
__copyright__ = '(C) 2020 by seminozhenko.ss'

__revision__ = '$Format:%H$'

from typing import Dict, Any, List

import processing
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingUtils,
                       QgsProcessingParameterDefinition,
                       QgsProcessingParameterField,
                       QgsProcessingParameterString,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingFeedback,
                       QgsProcessingContext,
                       QgsProcessingFeatureSource
                       )

from ...modules.optionParser import parseOptions

options = parseOptions(__file__)


class composeVertices(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    DESTFIELDS = "DESTFIELDS"
    SUBDESTFIELDS = "SUBDESTFIELDS"
    GROUPFIELDS = "GROUPFIELDS"
    GROUPFIELD = "GROUPFIELD"
    POINTFIELD = "POINTFIELD"
    SECTIONFIELD = "SECTIONFIELD"
    SUBSECTIONFIELD = "SUBSECTIONFIELD"
    GROUPEDFIELD = "GROUPEDFIELD"
    SECTIONS = 'SECTIONS'

    def __init__(self, plugin_dir):
        self.__plugin_dir = plugin_dir

        super().__init__()

    def initAlgorithm(self, config: Dict[str, Any]):
        self.addParameter(QgsProcessingParameterFeatureSource(
            name=self.INPUT,
            description='Входной слой',
            types=[QgsProcessing.TypeVectorAnyGeometry],
            defaultValue=None
        ))

        self.addParameter(QgsProcessingParameterField(
            name=self.DESTFIELDS,
            description='Поля, информация о которых должна быть сохранена в точках',
            defaultValue=options.get(self.DESTFIELDS, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Any,
            allowMultiple=True,
            optional=False
        ))

        # TODO придумать нормальное описание для параметров

        self.addParameter(QgsProcessingParameterField(
            name=self.SUBDESTFIELDS,
            description='Поля, информация о которых должна быть сохранена в точках 2',
            defaultValue=options.get(self.SUBDESTFIELDS, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            allowMultiple=True,
            optional=True
        ))

        self.addParameter(QgsProcessingParameterField(
            name=self.GROUPFIELDS,
            description='Поля по которым нужно сгруппировать полигоны',
            defaultValue=options.get(self.GROUPFIELDS, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Any,
            allowMultiple=True,
            optional=False
        ))

        param = QgsProcessingParameterField(
            name=self.GROUPFIELD,
            description='Имя для поля номера полигона',
            defaultValue=options.get(self.GROUPFIELD, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            allowMultiple=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterField(
            name=self.POINTFIELD,
            description='Имя поля для номера точки',
            defaultValue=options.get(self.POINTFIELD, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            allowMultiple=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterField(
            name=self.SECTIONFIELD,
            description='Имя поля для номера единицы группировки',
            defaultValue=options.get(self.SECTIONFIELD, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            allowMultiple=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterField(
            name=self.SUBSECTIONFIELD,
            description='Имя поля для единицы группировки 2',
            defaultValue=options.get(self.SUBSECTIONFIELD, None),
            parentLayerParameterName=self.INPUT,
            type=QgsProcessingParameterField.Numeric,
            allowMultiple=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        param = QgsProcessingParameterString(
            name=self.GROUPEDFIELD,
            description='Имя поля в котором буду сгруппированные значения',
            defaultValue=options.get(self.GROUPEDFIELD, None),
            multiLine=False,
            optional=False
        )
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

        self.addParameter(QgsProcessingParameterFeatureSink(
            name=self.SECTIONS,
            description='Результат',
            type=QgsProcessing.TypeVectorAnyGeometry,
            createByDefault=True,
            supportsAppend=True,
            defaultValue='TEMPORARY_OUTPUT'))

    def processAlgorithm(self, parameters: Dict[str, Any],
                         context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):

        result = dict()

        input: QgsProcessingFeatureSource = self.parameterAsSource(parameters, self.INPUT, context)

        destfields: List[str] = self.parameterAsFields(parameters, self.DESTFIELDS, context)
        if parameters[self.SUBDESTFIELDS]:
            subdestfields: List[str] = self.parameterAsFields(parameters, self.SUBDESTFIELDS, context)
        else:
            subdestfields = []
        groupfields: List[str] = self.parameterAsFields(parameters, self.GROUPFIELDS, context)
        groupfield: str = self.parameterAsString(parameters, self.GROUPFIELD, context)
        pointfield: str = self.parameterAsString(parameters, self.POINTFIELD, context)
        sectionfield: str = self.parameterAsString(parameters, self.SECTIONFIELD, context)
        subsectionfield: str = self.parameterAsString(parameters, self.SUBSECTIONFIELD, context)
        groupedfield: str = self.parameterAsString(parameters, self.GROUPEDFIELD, context)

        steps = len(subdestfields) + 2

        model_feedback = QgsProcessingMultiStepFeedback(steps, feedback)

        minimumfield = 'minval'
        output = parameters['INPUT']
        agg_for_end_step = dict()
        temppoinfield_min = pointfield
        temppoinfield_max = pointfield

        if feedback.isCanceled():
            return {}

        if len(subdestfields) > 0:
            is_last_val = True

            subdestfields_remain = subdestfields.copy()
            previousfield = subdestfields[-1]
            for indx, fieldname in enumerate(reversed(subdestfields)):
                subdestfields_remain.remove(fieldname)
                if is_last_val:
                    is_last_val = False

                    groupby = '"{}"'.format(subsectionfield)
                    input_str = '''with_variable(
                                    'arr',
                                    array_distinct(
                                        array_agg(
                                            expression:="{fieldname}",
                                            group_by:="{subsection}",
                                            order_by:="{fieldname}"
                                        )
                                    ),
                                    if(
                                        array_length(@arr) > 2,
                                        array_first(@arr) || '-' || array_last(@arr),
                                        array_to_string(@arr, ',')
                                    )
                                )'''.format(fieldname=fieldname, subsection=subsectionfield)


                else:
                    if not subdestfields_remain:
                        subdestfields_remain = [sectionfield]
                    temppoinfield_min = pointfield + "_min"
                    temppoinfield_max = pointfield + "_max"
                    groupby = '"{}"'.format('" || \' \' || "'.join(subdestfields_remain + [fieldname]))
                    input_str = '''
                                "{fieldname}" || '(' || array_to_string( 
                                                array_distinct(
                                                    array_agg( 
                                                        expression:= "{previousfield}", 
                                                        group_by:="{remainedfields}" || ' ' || "{fieldname}",
                                                        order_by:="{minimumfield}"
                                                        )
                                                )
                                            , ',') || ')'
                                    '''.format(fieldname=fieldname,
                                               previousfield=previousfield,
                                               minimumfield=minimumfield,
                                               remainedfields='" "'.join(subdestfields_remain))

                if feedback.isCanceled():
                    return {}

                aggregates = [{'aggregate': 'minimum',
                               'delimiter': ',',
                               'input': '"{}"'.format(temppoinfield_min),
                               'length': input.fields().field(pointfield).length(),
                               'name': pointfield + "_min",
                               'precision': input.fields().field(pointfield).precision(),
                               'type': input.fields().field(pointfield).type()},
                              {'aggregate': 'maximum',
                               'delimiter': ',',
                               'input': '"{}"'.format(temppoinfield_max),
                               'length': input.fields().field(pointfield).length(),
                               'name': pointfield + "_max",
                               'precision': input.fields().field(pointfield).precision(),
                               'type': input.fields().field(pointfield).type()},
                              {'aggregate': 'minimum',
                               'delimiter': ',',
                               'input': '"{}"'.format(fieldname),
                               'length': input.fields().field(fieldname).length(),
                               'name': minimumfield,
                               'precision': input.fields().field(fieldname).precision(),
                               'type': input.fields().field(fieldname).type()},
                              {'aggregate': 'first_value',
                               'delimiter': ',',
                               'input': input_str,
                               'length': 0,
                               'name': fieldname,
                               'precision': 0,
                               'type': 0}]

                extra_agg = []
                for fieldname_temp in subdestfields_remain + groupfields + destfields + [groupfield, sectionfield]:
                    extra_agg.append(
                        {'aggregate': 'first_value',
                         'delimiter': ',',
                         'input': '"{}"'.format(fieldname_temp),
                         'length': input.fields().field(fieldname_temp).length(),
                         'name': fieldname_temp,
                         'precision': input.fields().field(fieldname_temp).precision(),
                         'type': input.fields().field(fieldname_temp).type()}
                    )

                aggregates.extend(extra_agg)

                alg_params = {
                    'INPUT': output,
                    'GROUP_BY': groupby,
                    'AGGREGATES': aggregates,
                    'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
                }

                output = processing.run('native:aggregate',
                                        alg_params,
                                        context=context,
                                        feedback=model_feedback,
                                        is_child_algorithm=True)['OUTPUT']

                previousfield = fieldname

                model_feedback.setCurrentStep(indx + 1)

            if feedback.isCanceled():
                return {}

            previousfield = subdestfields[0]
            agg_for_end_step = {'aggregate': 'first_value',
                                'delimiter': ',',
                                'input': '''
                        array_to_string(
                                        array_distinct(
                                            array_agg(
                                                expression:= "{previousfield}",
                                                group_by:="{fieldname}",
                                                order_by:="{minimumfield}"
                                                )
                                        )
                                    , ',')
                            '''.format(fieldname=sectionfield,
                                       previousfield=previousfield,
                                       minimumfield=minimumfield
                                       ),
                                'length': 0,
                                'name': groupedfield,
                                'precision': 0,
                                'type': 0}

        if feedback.isCanceled():
            return {}

        groupby = '"{}"'.format(sectionfield)
        aggregates = [
            {'aggregate': 'minimum',
             'delimiter': ',',
             'input': '"{}"'.format(temppoinfield_min),
             'length': input.fields().field(pointfield).length(),
             'name': pointfield + "_min",
             'precision': input.fields().field(pointfield).precision(),
             'type': input.fields().field(pointfield).type()},
            {'aggregate': 'maximum',
             'delimiter': ',',
             'input': '"{}"'.format(temppoinfield_max),
             'length': input.fields().field(pointfield).length(),
             'name': pointfield + "_max",
             'precision': input.fields().field(pointfield).precision(),
             'type': input.fields().field(pointfield).type()}
        ]

        if agg_for_end_step:
            aggregates.append(agg_for_end_step)

        extra_agg = []
        for fieldname_temp in [groupfield] + destfields + groupfields + [sectionfield]:
            extra_agg.append(
                {'aggregate': 'first_value',
                 'delimiter': ',',
                 'input': '"{}"'.format(fieldname_temp),
                 'length': input.fields().field(fieldname_temp).length(),
                 'name': fieldname_temp,
                 'precision': input.fields().field(fieldname_temp).precision(),
                 'type': input.fields().field(fieldname_temp).type()}
            )

        extra_agg.extend(aggregates)
        aggregates = extra_agg

        alg_params = {
            'INPUT': output,
            'GROUP_BY': groupby,
            'AGGREGATES': aggregates,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }

        output = processing.run('native:aggregate',
                                alg_params,
                                context=context,
                                feedback=model_feedback,
                                is_child_algorithm=True)['OUTPUT']

        model_feedback.setCurrentStep(steps - 1)
        if feedback.isCanceled():
            return {}

        alg_params = {
            'INPUT': output,
            'EXPRESSION': '"{}"'.format(sectionfield),
            'ASCENDING': True,
            'NULLS_FIRST': False,
            'OUTPUT': 'TEMPORARY_OUTPUT'}

        output = processing.run("native:orderbyexpression",
                                alg_params,
                                context=context,
                                feedback=model_feedback,
                                is_child_algorithm=True
                                )['OUTPUT']

        model_feedback.setCurrentStep(steps)

        temp = QgsProcessingUtils.mapLayerFromString(output, context)

        (points, points_id) = self.parameterAsSink(parameters, self.SECTIONS, context, temp.fields(),
                                                   temp.wkbType(),
                                                   temp.sourceCrs())

        points.addFeatures(temp.getFeatures())
        result.update({self.SECTIONS: points_id})

        return result

    def name(self) -> str:
        return 'compose_vertices'

    def displayName(self) -> str:
        # return self.name()
        return 'Описание границ'

    def group(self) -> str:
        return 'Общие инструменты'

    def groupId(self) -> str:
        return 'LU'

    def createInstance(self) -> QgsProcessingAlgorithm:
        return composeVertices(self.__plugin_dir)

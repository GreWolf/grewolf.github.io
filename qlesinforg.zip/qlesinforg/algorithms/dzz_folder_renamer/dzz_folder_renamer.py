__author__ = 'seminozhenko.ss'
__date__ = '2020-01-10'
__copyright__ = '(C) 2020 by seminozhenko.ss'

__revision__ = '$Format:%H$'

import os
from typing import Dict, Any, List
import re

from PyQt5.QtCore import QVariant
from processing.modeler.ModelerDialog import ModelerDialog
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingUtils,
                       QgsCoordinateReferenceSystem,
                       QgsProcessingParameterExpression,
                       QgsProcessingParameterBoolean,
                       QgsWkbTypes,
                       QgsProcessingParameterDefinition,
                       QgsProcessingParameterField,
                       QgsProcessingParameterString,
                       QgsProcessingFeedback,
                       QgsProcessingContext,
                       QgsProject,
                       QgsApplication, QgsProcessingFeatureSource, QgsProcessingParameterCrs,
                       QgsProcessingMultiStepFeedback, QgsProcessingParameterEnum,
                       QgsProcessingParameterFolderDestination, QgsFeatureRequest, QgsExpression, QgsVectorLayer,
                       QgsField, QgsFields, QgsFeature, QgsFeatureSink, QgsProcessingParameterFile
                       )

from ...modules.functions import prepare_path
from ...modules.proximity import find_field

from ...widgets.expression_widget import CustomExpressionWrapper
from ...widgets.field_widget import CustomFieldWrapper
from ...modules.optionParser import parseOptions
from ...modules.proximity import proximity

from ..extract_vertices.extract_vertices import extractVertices
from ..excel_creator.excel_creator import excelCreator

# from modules.functions import prepare_path
# from modules.proximity import find_field
#
# from widgets.expression_widget import CustomExpressionWrapper
# from widgets.field_widget import CustomFieldWrapper
# from modules.optionParser import parseOptions
# from modules.proximity import proximity

from ..extract_vertices.extract_vertices import extractVertices
from ..excel_creator.excel_creator import excelCreator

# эти два импорта не удалять
import processing
from processing.core.Processing import Processing

options = parseOptions(__file__)


class dzzRenamer(QgsProcessingAlgorithm):
    FOLDER = 'INPUT'
    REPORT = 'REPORT'

    def __init__(self, plugin_dir):
        self.__plugin_dir = plugin_dir
        super().__init__()

    def initAlgorithm(self, config: Dict[str, Any]):

        self.addParameter(QgsProcessingParameterFile(
            name=self.FOLDER,
            description='Папка в которой необходимо преименовать папки',
            behavior=QgsProcessingParameterFile.Folder
        ))

        self.addParameter(QgsProcessingParameterFeatureSink(
            name=self.REPORT,
            description='Отчет',
            type=QgsProcessing.TypeVectorAnyGeometry
        ))

    def processAlgorithm(self, parameters: Dict[str, Any],
                         context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):
        result = dict()

        destfolder = self.parameterAsFile(parameters, self.FOLDER, context)

        fields_list = [QgsField("path", QVariant.String),
                       QgsField("old_name", QVariant.String),
                       QgsField("naw_name", QVariant.String),
                       QgsField("error", QVariant.String)]

        fields = QgsFields()
        for field in fields_list:
            fields.append(field)

        (report, report_id) = self.parameterAsSink(parameters, self.REPORT, context, fields,
                                                   QgsWkbTypes.NoGeometry, QgsCoordinateReferenceSystem())
        report: QgsFeatureSink

        dirs_count = 1
        for base, dirs, files in os.walk(destfolder):
            for _ in dirs:
                dirs_count += 1

        print('dirs_count', dirs_count)
        feedback.setProgress(0)

        curr_dirs_count = 0
        for root, dirnames, filenames in os.walk(destfolder):
            curr_dirs_count += 1
            rootfolder, old_name = root.rsplit(sep=os.sep, maxsplit=1)
            re_result = re.search(r"(.{4,})(_[0-9a-f]{40}$)", old_name, flags=re.IGNORECASE)
            if re_result:
                naw_name = re_result.group(1)
                error = None
                try:
                    os.rename(root, os.path.join(rootfolder, naw_name))
                except Exception as e:
                    error = str(e)
                    naw_name = None

                feat = QgsFeature(fields)
                feat["path"] = rootfolder
                feat["old_name"] = old_name
                feat["naw_name"] = naw_name
                feat["error"] = error

                report.addFeature(feat)

            feedback.setProgress(curr_dirs_count/dirs_count)

        print('curr_dirs_count', curr_dirs_count)
        result.update({self.REPORT: report_id})
        feedback.setProgress(100)
        return result

    def name(self) -> str:
        return 'dzz_renamer'

    def displayName(self) -> str:
        return 'Переименовать папки'

    def group(self) -> str:
        return 'ДЗЗ'

    def groupId(self) -> str:
        return 'DZZ'

    def createInstance(self) -> QgsProcessingAlgorithm:
        return dzzRenamer(self.__plugin_dir)


if __name__ == "__main__":
    QgsApplication.setPrefixPath(r'C:/OSGEO4~1/apps/qgis', True)
    qgs = QgsApplication([], False)
    qgs.initQgis()

    from processing.core.Processing import Processing
    from qgis.analysis import QgsNativeAlgorithms

    Processing.initialize()
    QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
    feedback = QgsProcessingFeedback()
    #
    # QgsExpressionContextUtils.globalScope()
    # QgsExpressionContextUtils.projectScope()

    context = QgsProcessingContext()
    context.setFeedback(feedback)
    context.setProject(QgsProject.instance())

    # processing.algorithmHelp()

    # parameters = {'DISSOLVE': True,
    #               'ERRORS': 'TEMPORARY_OUTPUT',
    #              'INPUT': 'd:/GoogleDrive/Разное/RLI/2019.12.02 - Бердову/Для Сергея/Бузулукское/Бузулукское сельское участковое_region.shp',
    #              'OUTPUT': 'TEMPORARY_OUTPUT',
    #              'SPECIES': 'C:/Users/seminozhenko.ss/PycharmProjects/okkh_plugin/resourses/species.xlsx|layername=species'}

    parameters = {
        'CRS': None,
        'FILTEREXPRESSION': '',
        'FOLDEROUTPUT': 'C:\\Users\\seminozhenko.ss\\AppData\\Roaming\\QGIS\\QGIS3\\profiles\\default\\python\\plugins\\qlesinforg\\output',
        'GROUPSORT': 'y_max($geometry)',
        'INPUT': 'postgres://dbname=\'gis\' host=82.148.12.172 port=5432 user=\'qgis\' password=\'LvlgCuHAA\' key=\'id\' checkPrimaryKeyUnicity=\'1\' table=\"(SELECT id, sri, mu, gir, kv, zk, mk, skp, sknr, ST_MakeValid(geom) as geom FROM public.tax WHERE (sri = 49 AND mu = 9 AND gir = 2 AND kv = 93) OR (sri = 49 AND mu = 9 AND gir = 2 AND kv = 75) OR (sri = 49 AND mu = 9 AND gir = 2 AND kv = 92) OR (sri = 49 AND mu = 9 AND gir = 2 AND kv = 74) OR (sri = 49 AND mu = 9 AND gir = 1 AND kv = 131))\" (geom)',
        'SOLIDNUMBERING': False, 'TYPES': [0, 1, 2]
    }

    algr = dzzRenamer(r"C:\Users\seminozhenko.ss\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\qlesinforg")
    algr.initAlgorithm(None)
    result = algr.run(parameters, context, feedback)

    print(result)

    qgs.exitQgis()

import os
from typing import Dict, Any, List, Tuple

from copy import copy
from math import floor, ceil

from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.cell.cell import Cell
from openpyxl import load_workbook, Workbook
from openpyxl.worksheet.cell_range import CellRange

from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingUtils,
                       QgsCoordinateReferenceSystem,
                       QgsExpression,
                       QgsProcessingParameterExpression,
                       QgsProcessingParameterBoolean,
                       QgsProcessingException,
                       QgsWkbTypes,
                       QgsProcessingParameterDefinition,
                       QgsProcessingParameterField,
                       QgsProcessingParameterString,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingFeedback,
                       QgsProcessingContext,
                       QgsProject,
                       QgsApplication, QgsProcessingFeatureSource, QgsProcessingParameterCrs,
                       QgsProcessingParameterFileDestination, QgsVectorLayer, QgsProcessingParameterFile, QgsFeature,
                       QgsProcessingParameterMatrix, QgsExpressionContextUtils, QgsExpressionContextScope,
                       QgsSQLStatement, QgsExpressionContext
                       )

from ...modules.optionParser import parseOptions
from ...modules.functions import prepare_path

options = parseOptions(__file__)


class excelCreator(QgsProcessingAlgorithm):
    TEMPLATE = 'TEMPLATE'
    EXTRAPARAMS = 'EXTRAPARAMS'
    FILEOUTPUT = 'FILEOUTPUT'

    def __init__(self, plugin_dir):
        self.__plugin_dir = plugin_dir

        self.err_template = """
                            Координаты: {}
                            Выражение: {}
                            Ошибка: {}
                            """

        super().__init__()

    def initAlgorithm(self, config: Dict[str, Any]):

        self.addParameter(QgsProcessingParameterFile(
            name=self.TEMPLATE,
            description="Шаблон",
            defaultValue=prepare_path(options.get(self.TEMPLATE, ""), self.__plugin_dir),
            fileFilter="*.xlsx"
        ))

        self.addParameter(QgsProcessingParameterMatrix(
            name=self.EXTRAPARAMS,
            description="Дополнительные параметры",
            headers=["Параметр", "Значение"],
            defaultValue=options.get(self.EXTRAPARAMS, None),
            optional=True
        ))

        self.addParameter(QgsProcessingParameterFileDestination(
            name=self.FILEOUTPUT,
            description="Результирующий файл",
            defaultValue=prepare_path(options.get(self.FILEOUTPUT, ""), self.__plugin_dir),
            fileFilter="*.xlsx"
        ))

    def processAlgorithm(self, parameters: Dict[str, Any],
                         context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):

        result = dict()

        template: str = self.parameterAsFile(parameters, self.TEMPLATE, context)

        # если поле (с optional=True) было оставлено пустым, то parameterAs выдает
        # значение по умолчанию, что в данном случае не нужно. Обрабатываем этот случай вручную
        if parameters[self.EXTRAPARAMS]:
            extraparams: List = self.parameterAsMatrix(parameters, self.EXTRAPARAMS, context)
        else:
            extraparams = []

        fileoutput: str = self.parameterAsFileOutput(parameters, self.FILEOUTPUT, context)

        # переводим список EXTRAPARAMS в словарь
        extraparams: Dict = dict(zip(extraparams[::2], extraparams[1::2]))

        # если есть дополнительные параметры, то создаем пространство (scope) и записываем
        # в него эти параметры. После работы алгоритма, это пространство удалим (Pop).
        needPop = False
        if len(extraparams) > 0:
            needPop = True
            scope = QgsExpressionContextScope("temp_scope")

            for key in extraparams:
                scope.setVariable(key, extraparams[key])

            context.expressionContext().appendScope(scope)

        # for num, scope in enumerate(context.expressionContext().scopes()):
        #     scope: QgsExpressionContextScope
        #     print(num, scope)
        #     print(scope.name())
        #     print("functionNames", scope.functionNames())
        #     print("variableCount", scope.variableCount())
        #     print("variableNames", scope.variableNames())

        # workbook = load_workbook(template, data_only=True)

        workbook = self.parse_workbook(template, context, feedback)

        # даляем созданное пространство, если оно было создано
        if needPop:
            "popScope", context.expressionContext().popScope()

        # destwb = Workbook()
        # dstws = destwb.active
        #
        # # копирум данные на новый лист
        # self.copydata(srcws, dstws)

        # destwb = Workbook()
        # destwb.copy_worksheet(worksheet)

        workbook.save(fileoutput)

        return result

    def parse_workbook(self, workbook_path: str, context: QgsProcessingContext,
                       feedback: QgsProcessingFeedback) -> Workbook:

        # TODO стоит подумать насчет расширения синтаксиса выражений (<...>), маркировать запросы как query=
        #  , выражения QGIS как expr=, ссылки на другие файлы - excel=.
        #  Добавить атрибут expand= ["left", "right", "down", "up"], который указывают в какую сторону расширять
        #  результат если расширение возможно, в противном случае весь результат собрать в одну ячейку как текст.
        #  Добавить атрибут displace= ["all", "current"], который показывает как сдвигать другие ячейки при
        #  разворачивании резельтата, без этого параметра результат наложится сверху.

        workbook = load_workbook(workbook_path, data_only=True)
        worksheet = workbook.active

        # скинируем лист EXCEL на наличие в нем выражений (<...>), запоминаем их координаты на листе
        variables = dict()

        for row in worksheet.rows:
            for cell in row:
                value = cell.value
                if isinstance(value, str):
                    value: str
                    value = value.strip().lower()
                    if value.startswith("<") and value.endswith(">"):
                        subval = value[1:-1]

                        if subval not in variables:
                            variables[subval] = [(cell.row, cell.col_idx)]
                        else:
                            variables[subval].append((cell.row, cell.col_idx))

        # вычисляем каждое выражение и записываем на лист результат
        for key in variables:
            # если присутствует слово selec то обрабатываем как sql запрос, иначе как выражение QGIS
            if 'select' in key:

                haveError = False

                # sql_statement = QgsSQLStatement(key)
                # if sql_statement.hasParserError():
                #     haveError = True
                #     error_msg = self.err_template.format(variables[key], key, sql_statement.parserErrorString())
                #     feedback.pushInfo(error_msg)
                #
                # check = sql_statement.doBasicValidationChecks()
                # if not check[0]:
                #     haveError = True
                #     error_msg = self.err_template.format(variables[key], key, check[1])
                #     feedback.pushInfo(error_msg)

                if not haveError:
                    vlayer = QgsVectorLayer("?query={}".format(key), "virtual", "virtual")
                    # if vlayer.isValid() and vlayer.featureCount() > 0:

                    if vlayer.isValid():
                        part_count = ceil(vlayer.featureCount() / len(variables[key]))

                        for idx, feat in enumerate(vlayer.getFeatures()):
                            feat: QgsFeature
                            curr_init_row, curr_init_column = variables[key][idx // part_count]

                            # CellRange(min_col=worksheet.min_column,
                            #           min_row=worksheet.max_row - curr_init_row - 1,
                            #           max_row=worksheet.max_row,
                            #           max_col=worksheet.max_column)

                            curr_row = idx % part_count
                            for curr_col, field in enumerate(feat.fields().names()):
                                # ValueError: Cannot convert NULL to Excel
                                # if curr_row > 0 and worksheet.cell(row=curr_init_row + curr_row, column=curr_init_column + curr_col).value:
                                #     cell_range= CellRange(min_col=curr_init_column + curr_col,
                                #               min_row=curr_init_row + curr_row,
                                #               max_row=worksheet.max_row,
                                #               max_col=curr_init_column + curr_col)
                                #     worksheet.move_range(cell_range, rows=1, cols=0)

                                worksheet.cell(row=curr_init_row + curr_row, column=curr_init_column + curr_col,
                                               value=feat[field])

                    else:
                        error_msg = self.err_template.format(variables[key], key, "Ошибка в SQL запросе")
                        feedback.pushInfo(error_msg)

            elif ".xlsx" in key:
                path = key
                if not os.path.isabs(path):
                    path = os.path.join(os.path.dirname(workbook_path), path)

                subworkbook = self.parse_workbook(path, context, feedback)
                for curr_init_row, curr_init_column in variables[key]:
                    self.copydata(subworkbook.active, worksheet, curr_init_row - 1, curr_init_column - 1)

            else:
                expr = QgsExpression(key)
                if expr.prepare(context.expressionContext()):
                    try:
                        expr_result = expr.evaluate(context.expressionContext())
                    except TypeError as e:
                        error_msg = self.err_template.format(variables[key], key, str(e))
                        feedback.pushInfo(error_msg)
                    else:
                        # TODO блоки try-except убрать в функцию

                        # TODO реализовать перевод PyQt дат в питоновские после вычисления выражений
                        #  PyQt5.QtCore.QTime(20, 27, 40, 304)
                        #  PyQt5.QtCore.QDate(2021, 2, 4)
                        #  PyQt5.QtCore.QDateTime(2021, 2, 4, 20, 27, 40, 304)

                        for curr_init_row, curr_init_column in variables[key]:
                            try:
                                worksheet.cell(row=curr_init_row, column=curr_init_column,
                                               value=expr_result if expr_result else "")
                            except ValueError:
                                # TODO подумать над поведением при list и dict. Лист может сначала разворачивать
                                #  по горизонтали, а вложенные списки по вертикали. Или наоборот. А если вдруг
                                #  будет третий уровень списков, то перегонять их в str.
                                #  Что если в списке будут dict или в dict будут списки?
                                #  Что насчет хитрой рекурсивной функции?

                                if isinstance(expr_result, list):
                                    for curr_col, item in enumerate(expr_result):
                                        try:
                                            worksheet.cell(row=curr_init_row, column=curr_init_column + curr_col,
                                                           value=item)
                                        except ValueError:
                                            worksheet.cell(row=curr_init_row, column=curr_init_column + curr_col,
                                                           value=str(item))
                                elif isinstance(expr_result, dict):
                                    for curr_row, item in enumerate(expr_result.keys()):
                                        try:
                                            worksheet.cell(row=curr_init_row + curr_row, column=curr_init_column,
                                                           value=item)
                                        except ValueError:
                                            worksheet.cell(row=curr_init_row + curr_row, column=curr_init_column,
                                                           value=str(item))

                                        try:
                                            worksheet.cell(row=curr_init_row + curr_row, column=curr_init_column + 1,
                                                           value=expr_result[item])
                                        except ValueError:
                                            worksheet.cell(row=curr_init_row + curr_row, column=curr_init_column + 1,
                                                           value=str(expr_result[item]))
                                else:
                                    worksheet.cell(row=curr_init_row, column=curr_init_column, value=str(expr_result))
                else:
                    if expr.hasParserError():
                        error_msg = self.err_template.format(variables[key], key, expr.parserErrorString())
                        feedback.pushInfo(error_msg)

                    if expr.hasEvalError():
                        error_msg = self.err_template.format(variables[key], key, expr.evalErrorString())
                        feedback.pushInfo(error_msg)

        return workbook

    @staticmethod
    def copydata(src_worksheet: Worksheet, dst_worksheet: Worksheet, drow: int = 0, dcol: int = 0) -> Tuple[
        int, int, int, int]:
        for row in src_worksheet.rows:
            for cell in row:
                if isinstance(cell, Cell):
                    new_cell: Cell = dst_worksheet.cell(row=cell.row + drow, column=cell.col_idx + dcol,
                                                        value=cell.value)
                    if cell.has_style:
                        new_cell.font = copy(cell.font)
                        new_cell.border = copy(cell.border)
                        new_cell.fill = copy(cell.fill)
                        new_cell.number_format = copy(cell.number_format)
                        new_cell.protection = copy(cell.protection)
                        new_cell.alignment = copy(cell.alignment)

        for cellrange in src_worksheet.merged_cells.ranges:
            dst_worksheet.merge_cells(start_row=cellrange.min_row + drow,
                                      end_row=cellrange.max_row + drow,
                                      start_column=cellrange.min_col + dcol,
                                      end_column=cellrange.max_col + dcol)

        return src_worksheet.min_row, src_worksheet.max_row, src_worksheet.min_column, src_worksheet.max_column

    def name(self) -> str:
        return 'create_excel'

    def displayName(self) -> str:
        # return self.name()
        return 'Создание excel таблицы по шаблону'

    def group(self) -> str:
        return 'Общие инструменты'

    def groupId(self) -> str:
        return 'LU'

    def createInstance(self) -> QgsProcessingAlgorithm:
        return excelCreator(self.__plugin_dir)


if __name__ == "__main__":
    QgsApplication.setPrefixPath(r'C:/OSGEO4~1/apps/qgis', True)
    qgs = QgsApplication([], False)
    qgs.initQgis()

    import processing
    from processing.core.Processing import Processing
    from qgis.analysis import QgsNativeAlgorithms

    Processing.initialize()
    QgsApplication.processingRegistry().addProvider(QgsNativeAlgorithms())
    feedback = QgsProcessingFeedback()
    #
    # QgsExpressionContextUtils.globalScope()
    # QgsExpressionContextUtils.projectScope()

    context = QgsProcessingContext()
    context.setFeedback(feedback)
    context.setProject(QgsProject.instance())

    # processing.algorithmHelp()

    # parameters = {'DISSOLVE': True,
    #               'ERRORS': 'TEMPORARY_OUTPUT',
    #              'INPUT': 'd:/GoogleDrive/Разное/RLI/2019.12.02 - Бердову/Для Сергея/Бузулукское/Бузулукское сельское участковое_region.shp',
    #              'OUTPUT': 'TEMPORARY_OUTPUT',
    #              'SPECIES': 'C:/Users/seminozhenko.ss/PycharmProjects/okkh_plugin/resourses/species.xlsx|layername=species'}

    parameters = {'EXTRAPARAM': ['test', 123, 'crs', 432],
                  'FILEOUTPUT': 'C:/Users/seminozhenko.ss/PycharmProjects/qlesinforg/doc_templates/tst2.xlsx',
                  'TEMPLATE': 'C:\\Users\\seminozhenko.ss\\PycharmProjects\\qlesinforg\\doc_templates\\Книга2.xlsx'}

    algr = excelCreator("asdf")
    algr.initAlgorithm(None)
    result = algr.run(parameters, context, feedback)

    print(result)

    qgs.exitQgis()

from .QGIS_LTR_FieldsMapper.FieldsMappingPanel import (
    FieldsMappingModel,
    FieldsMappingPanel,
    FieldsMappingWidgetWrapper,
)

from qgis.PyQt.QtCore import (
    QCoreApplication,
    QVariant,
    Qt,
)
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QStyledItemDelegate,
)
from qgis.core import (QgsField,
                       QgsProcessingParameterDefinition,
                       )

def getInFieldsWidgetWrapper(INFIELDS, TYPES, COLLATION, proximity):

    class InFieldsModel(FieldsMappingModel):

        def configure(self):
            self.columns = [{
                'name': 'type',
                'type': QVariant.String,
                'header': QCoreApplication.translate('InFieldsModel', "Type"),
                'persistentEditor': True
            }, {
                'name': 'field',
                # 'type': QgsExpression,
                'type': QVariant.String,
                'header': QCoreApplication.translate('InFieldsModel', "Field name"),
                'persistentEditor': True
            }]

        def loadLayerFields(self, layer):
            self.beginResetModel()

            self._mapping = []

            if layer:
                field_names = [field.name() for field in layer.fields()]
                for infield in INFIELDS:
                    proximity_list = [proximity(infield["name"], field_name) for field_name in field_names]
                    result_field = layer.fields()[proximity_list.index(max(proximity_list))]
                    # self.type = infield["display_name"]
                    self.type = infield["type"]
                    self._mapping.append(self.newField(result_field))

            else:
                for infield in INFIELDS:
                    # self.type = infield["display_name"]
                    self.type = infield["type"]
                    self._mapping.append(self.newField(QgsField(infield["name"])))

            self.endResetModel()

        def newField(self, field=None):

            if field is None:
                return {
                    'type': QVariant.Invalid,
                    'field': "",
                }

            return {
                'type': self.type,
                # 'field': QgsExpression.quotedColumnRef(field.name()),
                'field': field.name(),
            }

    class TypesDelegate(QStyledItemDelegate):

        def __init__(self, parent=None):
            super(TypesDelegate, self).__init__(parent)

        def createEditor(self, parent, option, index):
            editor = QComboBox(parent)
            for typename in TYPES:
                # editor.addItem(typename, typename)
                editor.addItem(COLLATION[typename], typename)
            return editor

        def setEditorData(self, editor, index):
            if not editor:
                return
            value = index.model().data(index, Qt.EditRole)
            editor.setCurrentIndex(editor.findData(value))

        def setModelData(self, editor, model, index):
            if not editor:
                return
            value = editor.currentData()
            if value is None:
                value = QVariant.Invalid
            model.setData(index, value)


    class FieldsDelegate(QStyledItemDelegate):

        def __init__(self, parent=None):
            super(FieldsDelegate, self).__init__(parent)

        def createEditor(self, parent, option, index):
            editor = QComboBox(parent)
            if index.model().layer():
                for field in index.model().layer().fields():
                    editor.addItem(field.name(), field.name())
                return editor

        def setEditorData(self, editor, index):
            if not editor:
                return
            value = index.model().data(index, Qt.EditRole)
            editor.setCurrentIndex(editor.findData(value))

        def setModelData(self, editor, model, index):
            if not editor:
                return
            value = editor.currentData()
            if value is None:
                value = QVariant.Invalid
            model.setData(index, value)


    class InFieldsPanel(FieldsMappingPanel):

        def configure(self):
            self.model = InFieldsModel()
            self.fieldsView.setModel(self.model)
            self.model.rowsInserted.connect(self.on_model_rowsInserted)
            self.loadFromLayerLabel.setVisible(0)
            self.layerCombo.setVisible(0)
            self.loadLayerFieldsButton.setVisible(0)

            self.setDelegate('type', TypesDelegate(self))
            self.setDelegate('field', FieldsDelegate(self))

        def setLayer(self, layer):
            if self.model.layer() == layer:
                return
            self.model.setLayer(layer)
            # if layer is None:
            #     return
            if self.model.rowCount() == 0:
                self.on_resetButton_clicked()
                return
            self.on_resetButton_clicked()


    class InFieldsWidgetWrapper(FieldsMappingWidgetWrapper):

        def createPanel(self, parentLayerParameterName='INPUT'):
            self._parentLayerParameter = parentLayerParameterName
            return InFieldsPanel()

    return InFieldsWidgetWrapper



class ParameterInFields(QgsProcessingParameterDefinition):

    def __init__(self, name, description, parentLayerParameterName='INPUT'):
        super().__init__(name, description)
        self._parentLayerParameter = parentLayerParameterName

    def clone(self):
        copy = ParameterInFields(self.name(), self.description(), self._parentLayerParameter)
        return copy

    def type(self):
        return 'infields'

    def checkValueIsAcceptable(self, value, context=None):
        if not isinstance(value, list):
            return False
        for field_def in value:
            if not isinstance(field_def, dict):
                return False
            if not field_def.get('type', False):
                return False
            if not field_def.get('field', False):
                return False
        return True

    def valueAsPythonString(self, value, context):
        return str(value)

    def asScriptCode(self):
        raise NotImplementedError()

    @classmethod
    def fromScriptCode(cls, name, description, isOptional, definition):
        raise NotImplementedError()

    def parentLayerParameter(self):
        return self._parentLayerParameter
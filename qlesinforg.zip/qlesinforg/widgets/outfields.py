from .QGIS_LTR_FieldsMapper.FieldsMappingPanel import (
    FieldsMappingModel,
    FieldsMappingPanel,
    FieldsMappingWidgetWrapper,
)

from qgis.PyQt.QtCore import (
    QCoreApplication,
    QVariant,
    Qt,
)
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QStyledItemDelegate,
)
from qgis.core import (QgsProcessingParameterDefinition,
                       )


def getOutFieldsWidgetWrapper(OUTFIELDS, COLLATION):
    class OutFieldsModel(FieldsMappingModel):

        def configure(self):
            self.columns = [{
                'name': 'outType',
                'type': QVariant.String,
                'header': QCoreApplication.translate('OutFieldsModel', "Destination"),
                'persistentEditor': True
            }, {
                'name': 'name',
                # 'type': QgsExpression,
                'type': QVariant.String,
                'header': QCoreApplication.translate('OutFieldsModel', "Field name"),
                # 'persistentEditor': True
            }, {
                'name': 'prec',
                'type': QVariant.Int,
                'header': QCoreApplication.translate('OutFieldsModel', "Precision"),
                # 'persistentEditor': True
            }, {
                'name': 'type',
                'type': QVariant.Int,
                'header': QCoreApplication.translate('OutFieldsModel', "Data type"),
                'persistentEditor': True
            },
            ]

        def loadLayerFields(self, layer):
            self.beginResetModel()

            self._mapping = []

            for outfield in OUTFIELDS:
                self._mapping.append(self.newField(outfield))

            self.endResetModel()

        def newField(self, field=None):

            if field is None:
                return {
                    'outType': "",
                    'name': "",
                    'prec': "",
                    'type': QVariant.Invalid,
                }

            return {
                'outType': field['outType'],
                'name': field['name'],
                'prec': field['prec'],
                'type': field['type'],
            }

        def flags(self, index):
            if (index.column() == 0):
                return Qt.ItemFlags(Qt.ItemIsEnabled)
            else:
                return Qt.ItemFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)


    class OutTypesDelegate(QStyledItemDelegate):
        # COLLATION = {
        #     "out___tur1h1": QCoreApplication.translate('OutFieldsModel', "tur1h1 field"),
        #     "out___bon": QCoreApplication.translate('OutFieldsModel', "bon field"),
        #     "out___amz1": QCoreApplication.translate('OutFieldsModel', "amz1 field"),
        #     "out___fpl": QCoreApplication.translate('OutFieldsModel', "forest PL field"),
        #     "out___nfpl": QCoreApplication.translate('OutFieldsModel', "nonforest PL field"),
        #     "out___vmr": QCoreApplication.translate('OutFieldsModel', "vmr field"),
        # }

        def __init__(self, parent=None):
            super(OutTypesDelegate, self).__init__(parent)

        def createEditor(self, parent, option, index):
            editor = QComboBox(parent)
            # editor.setEditable(False)
            # editor.setDisabled(False)
            for typename in COLLATION:
                # editor.addItem(typename, typename)
                editor.addItem(COLLATION[typename], typename)
            return editor

        def setEditorData(self, editor, index):
            if not editor:
                return
            value = index.model().data(index, Qt.EditRole)
            editor.setCurrentIndex(editor.findData(value))

        def setModelData(self, editor, model, index):
            if not editor:
                return
            value = editor.currentData()
            if value is None:
                value = QVariant.Invalid
            model.setData(index, value)



    class OutDataTypesDelegate(QStyledItemDelegate):

        COLLATION = {
            QVariant.Date: "Date",
            QVariant.DateTime: "DateTime",
            QVariant.Double: "Double",
            QVariant.Int: "Integer",
            QVariant.LongLong: "Integer64",
            QVariant.String: "String",
            QVariant.Bool: "Boolean"
        }

        def __init__(self, parent=None):
            super(OutDataTypesDelegate, self).__init__(parent)

        def createEditor(self, parent, option, index):
            editor = QComboBox(parent)
            for typename in self.COLLATION:
                # editor.addItem(typename, typename)
                editor.addItem(self.COLLATION[typename], typename)
            return editor

        def setEditorData(self, editor, index):
            if not editor:
                return
            value = index.model().data(index, Qt.EditRole)
            editor.setCurrentIndex(editor.findData(value))

        def setModelData(self, editor, model, index):
            if not editor:
                return
            value = editor.currentData()
            if value is None:
                value = QVariant.Invalid
            model.setData(index, value)


    class OutFieldsPanel(FieldsMappingPanel):

        def configure(self):
            self.model = OutFieldsModel()
            self.fieldsView.setModel(self.model)
            self.model.rowsInserted.connect(self.on_model_rowsInserted)
            self.loadFromLayerLabel.setVisible(0)
            self.layerCombo.setVisible(0)
            self.loadLayerFieldsButton.setVisible(0)

            self.addButton.setVisible(0)
            self.deleteButton.setVisible(0)
            self.upButton.setVisible(0)
            self.downButton.setVisible(0)
            self.resetButton.setVisible(0)

            self.setDelegate('outType', OutTypesDelegate(self))
            self.setDelegate('type', OutDataTypesDelegate(self))

        def setLayer(self, layer):
            pass


    class OutFieldsWidgetWrapper(FieldsMappingWidgetWrapper):

        def createPanel(self, parentLayerParameterName='INPUT'):
            self._parentLayerParameter = parentLayerParameterName
            return OutFieldsPanel()

        def postInitialize(self, wrappers):
            super().postInitialize(wrappers)
            self.panel.on_resetButton_clicked()

    return OutFieldsWidgetWrapper


class ParameterOutFields(QgsProcessingParameterDefinition):

    def __init__(self, name, description, parentLayerParameterName='INPUT'):
        super().__init__(name, description)
        self._parentLayerParameter = parentLayerParameterName

    def clone(self):
        copy = ParameterOutFields(self.name(), self.description(), self._parentLayerParameter)
        return copy

    def type(self):
        return 'infields'

    def checkValueIsAcceptable(self, value, context=None):
        if not isinstance(value, list):
            return False
        for field_def in value:
            if not isinstance(field_def, dict):
                return False
            if not field_def.get('outType', False):
                return False
            if not field_def.get('name', False):
                return False
            precval = field_def.get('prec', False)
            if not precval and precval !=0:
                return False
            if precval < 0:
                return False
            if not field_def.get('type', False):
                return False
        return True

    def valueAsPythonString(self, value, context):
        return str(value)

    def asScriptCode(self):
        raise NotImplementedError()

    @classmethod
    def fromScriptCode(cls, name, description, isOptional, definition):
        raise NotImplementedError()

    def parentLayerParameter(self):
        return self._parentLayerParameter
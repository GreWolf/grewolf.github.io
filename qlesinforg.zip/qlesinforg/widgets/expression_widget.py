from processing.gui.wrappers import (
    ExpressionWidgetWrapper
)
from qgis.core import (QgsExpression,
                       )
from qgis.gui import (
    QgsProcessingGui,
)
from ..modules.proximity import find_field
# from modules.proximity import find_field

DIALOG_STANDARD = QgsProcessingGui.Standard
DIALOG_BATCH = QgsProcessingGui.Batch
DIALOG_MODELER = QgsProcessingGui.Modeler

class CustomExpressionWrapper(ExpressionWidgetWrapper):

    def parentLayerChanged(self, wrapper):
        self.setLayer(wrapper.parameterValue())

        outExpression = self.parameterDefinition().defaultValue()

        if self.widget.layer():
            for infield in QgsExpression(self.parameterDefinition().defaultValue()).referencedColumns():
                outfield = find_field(infield, self.widget.layer().fields())
                outExpression = outExpression.replace(infield, outfield)
        else:
            outExpression = self.parameterDefinition().defaultValue()

        self.setValue(outExpression)

    def postInitialize(self, wrappers):
        for wrapper in wrappers:
            if wrapper.parameterDefinition().name() == self.parameterDefinition().parentLayerParameterName():
                if self.dialogType in (DIALOG_STANDARD, DIALOG_BATCH):
                    self.setLayer(wrapper.parameterValue())
                    # если не работает, то раскомментить
                    # self.parentLayerChanged(wrapper)
                    wrapper.widgetValueHasChanged.connect(self.parentLayerChanged)
                break

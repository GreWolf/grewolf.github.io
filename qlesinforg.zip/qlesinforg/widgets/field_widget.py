from processing.gui.wrappers import (
    TableFieldWidgetWrapper
)
from qgis.core import (QgsExpression,
                       )
from qgis.gui import (
    QgsProcessingGui,
)

from ..modules.proximity import find_field
# from modules.proximity import find_field

DIALOG_STANDARD = QgsProcessingGui.Standard
DIALOG_BATCH = QgsProcessingGui.Batch
DIALOG_MODELER = QgsProcessingGui.Modeler

class CustomFieldWrapper(TableFieldWidgetWrapper):

    def parentValueChanged(self, wrapper):
        value = wrapper.parameterValue()
        if isinstance(value, str) and value in self.parent_file_based_layers:
            self.setLayer(self.parent_file_based_layers[value])
        else:
            self.setLayer(value)
            if isinstance(value, str):
                self.parent_file_based_layers[value] = self._layer

        # self.setLayer(wrapper.parameterValue())

        # outExpression = self.parameterDefinition().defaultValue()

        out_fields = []

        # if self.widget.layer():
        if self._layer:
            for defautl_field in self.parameterDefinition().defaultValue():
                outfield = find_field(defautl_field, self._layer.fields().names())
                out_fields.append(outfield)
        else:
            out_fields = self.parameterDefinition().defaultValue()

        self.setValue(out_fields)

    def postInitialize(self, wrappers):
        for wrapper in wrappers:
            if wrapper.parameterDefinition().name() == self.parameterDefinition().parentLayerParameterName():
                if self.dialogType in (DIALOG_STANDARD, DIALOG_BATCH):
                    self.setLayer(wrapper.parameterValue())
                    # self.parentValueChanged(wrapper)
                    wrapper.widgetValueHasChanged.connect(self.parentValueChanged)
                break
from copy import copy
from typing import Tuple

from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.cell.cell import Cell
from openpyxl import load_workbook, Workbook


def copydata(src_worksheet: Worksheet, dst_worksheet: Worksheet, drow: int, dcol: int) -> Tuple[int, int, int, int]:
    for row in src_worksheet.rows:
        for cell in row:
            if isinstance(cell, Cell):
                new_cell: Cell = dst_worksheet.cell(row=cell.row + drow, column=cell.col_idx + dcol,
                                                    value=cell.value)
                if cell.has_style:
                    new_cell.font = copy(cell.font)
                    new_cell.border = copy(cell.border)
                    new_cell.fill = copy(cell.fill)
                    new_cell.number_format = copy(cell.number_format)
                    new_cell.protection = copy(cell.protection)
                    new_cell.alignment = copy(cell.alignment)

    for cellrange in src_worksheet.merged_cells.ranges:
        dst_worksheet.merge_cells(start_row=cellrange.min_row + drow,
                                  end_row=cellrange.max_row + drow,
                                  start_column=cellrange.min_col + dcol,
                                  end_column=cellrange.max_col + dcol)

    return src_worksheet.min_row, src_worksheet.max_row, src_worksheet.min_column, src_worksheet.max_column


if __name__ == "__main__":
    srcwb = load_workbook('src.xlsx')
    srcws = srcwb.active

    destwb = Workbook()
    dstws = destwb.active

    copydata(srcws, dstws, 5, 5)

    destwb.save("test.xlsx")

import os

from PyQt5.QtXml import QDomDocument
from qgis.core import QgsVectorLayer, QgsProject, QgsPrintLayout, QgsReadWriteContext


class Atlas:
    # модель для работы с атласом

    def __init__(self, plugin_dir: str) -> None:
        self.__project = QgsProject.instance()
        self.__plugin_dir = plugin_dir
        # будущий макет карты
        self.__layout = QgsPrintLayout(self.__project)

    @property
    def layout(self) -> QgsPrintLayout:
        return self.__layout

    def create_atlas(self, coverage_layer: QgsVectorLayer, hide_coverage: bool = True, sort_feture: bool = True,
                     page_name_exp: str = "INDEX", sort_expr: str = "id_horizontal",
                     file_name_expr: str = "'output_' || \"INDEX\"") -> None:
        # создание аталаса

        # чтение файла с макетом макета)
        template_file = open(os.path.join(self.__plugin_dir, r"map_templates", "form 1.1.qpt"))
        template_content = template_file.read()
        template_file.close()
        document = QDomDocument()
        document.setContent(template_content)
        self.__layout.loadFromTemplate(document, QgsReadWriteContext())

        # TODO подумат насчет того, чтобы сохранить из слоев тему и использовать ее в атласе

        # TODO подумать насчет правильной обработки масштаба

        # настройка атласа
        atlas = self.__layout.atlas()
        atlas.setEnabled(True)
        atlas.setCoverageLayer(coverage_layer)
        atlas.setHideCoverage(hide_coverage)
        atlas.setPageNameExpression(page_name_exp)
        atlas.setSortExpression(sort_expr)
        atlas.setFilenameExpression(file_name_expr)
        atlas.setSortFeatures(sort_feture)

        # добавления макета в список макетов
        self.__project.layoutManager().addLayout(self.__layout)

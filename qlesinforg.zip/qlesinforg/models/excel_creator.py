import re
from copy import copy
from math import floor, ceil
from typing import Tuple

from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.cell.cell import Cell
from openpyxl import load_workbook, Workbook
from qgis.core import QgsVectorLayer, QgsFeatureRequest, QgsFeature


class excelCreator:
    def __init__(self):
        # self.__destpath = destpath

        self.__srcpath = r"C:\Users\seminozhenko.ss\PycharmProjects\qlesinforg\doc_templates\Книга2.xlsx"

        self.srcwb = load_workbook(self.__srcpath)
        self.srcws = self.srcwb.active

        self.destwb = Workbook()
        self.dstws = self.destwb.active

        self.layer = QgsVectorLayer(
            r"C:\Users\seminozhenko.ss\PycharmProjects\qlesinforg\doc_templates\POINTS.gpkg",
            "points",
            "ogr"
        )

        self.values = {
            # "crs": "EPSG:1234",
            "crs": self.layer.crs().authid(),
            "points": self.layer
        }

        self.variables = dict()
        self.scan_src()
        self.fill_src()
        print("asdf")

    def scan_src(self):
        # variables = dict()
        for row in self.srcws.rows:
            for cell in row:
                value = cell.value
                if isinstance(value, str):
                    value: str
                    value = value.strip().lower()
                    if value.startswith("<") and value.endswith(">"):
                        subval = value[1:-1]

                        if 'select' in subval:
                            subval = tuple([subval, None])
                        elif ('[' in subval) and (']' in subval):
                            subval = tuple(subval.replace(']', '').split("["))
                        else:
                            subval = tuple([subval, None])

                        if subval not in self.variables:
                            self.variables[subval] = [(cell.row, cell.col_idx)]
                        else:
                            self.variables[subval].append((cell.row, cell.col_idx))

    def fill_src(self):
        for key in self.variables:
            # val = self.variables[key]

            if key[0] in self.values:
                value = self.values[key[0]]
                if key[1]:
                    if isinstance(value, QgsVectorLayer):
                        if key[1] in value.fields().names():
                            part_count = ceil(value.featureCount() / len(self.variables[key]))

                            for idx, feat in enumerate(value.getFeatures()):
                                curr_init_row, curr_init_column = self.variables[key][idx // part_count]
                                curr_row = idx % part_count
                                self.srcws.cell(row=curr_init_row + curr_row, column=curr_init_column, value=feat[key[1]])

                else:
                    for row, column in self.variables[key]:
                        if isinstance(self.values[key[0]], QgsVectorLayer):
                            self.srcws.cell(row=row, column=column, value=str(value))
                        else:
                            self.srcws.cell(row=row, column=column, value=value)

            else:
                if 'select' in key[0]:
                    # query = key[0]
                    # for key in self.values:
                    #     if key in query:
                    #         value = self.values[key]
                    #         if isinstance(value, QgsVectorLayer):
                    #             query = query.replace(key, value.id())
                    #         else:
                    #             query = query.replace(key, value)

                    vlayer = QgsVectorLayer("?query={}".format(key[0]), "virtual", "virtual")
                    if vlayer.isValid():
                        part_count = ceil(vlayer.featureCount() / len(self.variables[key]))

                        for idx, feat in enumerate(vlayer.getFeatures()):
                            feat: QgsFeature
                            curr_init_row, curr_init_column = self.variables[key][idx // part_count]
                            curr_row = idx % part_count
                            for curr_col, field in enumerate(feat.fields().names()):
                                self.srcws.cell(row=curr_init_row + curr_row, column=curr_init_column + curr_col, value=feat[field])


            # if (len(val) == 1) and (key in self.values):
            #     print(self.srcws.cell(
            #         row=val[0][0],
            #         column=val[0][1],
            #         value=self.values[key]))
            #
            # elif len(val) > 1:
            #     pass

    @staticmethod
    def copydata(src_worksheet: Worksheet, dst_worksheet: Worksheet, drow: int = 0, dcol: int = 0) -> Tuple[
                                                                                        int, int, int, int]:
        for row in src_worksheet.rows:
            for cell in row:
                if isinstance(cell, Cell):
                    new_cell: Cell = dst_worksheet.cell(row=cell.row + drow, column=cell.col_idx + dcol,
                                                        value=cell.value)
                    if cell.has_style:
                        new_cell.font = copy(cell.font)
                        new_cell.border = copy(cell.border)
                        new_cell.fill = copy(cell.fill)
                        new_cell.number_format = copy(cell.number_format)
                        new_cell.protection = copy(cell.protection)
                        new_cell.alignment = copy(cell.alignment)

        for cellrange in src_worksheet.merged_cells.ranges:
            dst_worksheet.merge_cells(start_row=cellrange.min_row + drow,
                                      end_row=cellrange.max_row + drow,
                                      start_column=cellrange.min_col + dcol,
                                      end_column=cellrange.max_col + dcol)

        return src_worksheet.min_row, src_worksheet.max_row, src_worksheet.min_column, src_worksheet.max_column

if __name__ == "__main__":
    crtor = excelCreator()
    crtor.copydata(crtor.srcws, crtor.dstws)
    crtor.destwb.save(r"C:\Users\seminozhenko.ss\PycharmProjects\qlesinforg\doc_templates\tst.xlsx")


import os
from typing import Dict, Optional, Tuple

import processing
from processing.modeler.ModelerDialog import ModelerDialog
from qgis.core import QgsDataSourceUri, QgsFeature, QgsVectorLayer, QgsDataProvider

from ..functions import check_layer_exists, load_layer_from_db, load_layer_from_layer, set_style

# class NoLayerException(Exception):
#     pass


class ActiveOrder:
    # Класс для обработки слоев конкретной заявки (active_order в load_data)

    # Имена слоев для отображения в QGIS
    ugeom_name = "Вектор заказа"
    sknr_name = "Категории"
    sknr_full_name = "Выдела"
    sknr_full_lines_name = "Выдела (границы)"
    kv_name = "Квартала"
    kv_lines_name = "Квартала (границы)"

    def __init__(self, connection: Dict[str, str], plugin_dir: str) -> None:
        self.__uri = QgsDataSourceUri()
        self.__uri.setConnection(**connection)

        self.__plugin_dir = plugin_dir

        # загрузка модели перевода полигонов в линии
        self.__dlg = ModelerDialog()
        self.__dlg.loadModel(os.path.join(self.__plugin_dir, r"qgis_models", "polygons_to_lines.model3"))

        # будущие слои
        self.__ugeom: Optional[QgsVectorLayer] = None
        self.__sknr: Optional[QgsVectorLayer] = None
        self.__sknr_full: Optional[QgsVectorLayer] = None
        self.__sknr_full_lines: Optional[QgsVectorLayer] = None
        self.__kv: Optional[QgsVectorLayer] = None
        self.__kv_lines: Optional[QgsVectorLayer] = None

        # флаги, показывающие необходимость загрузки стиля для слоя
        self.__need_ugeom_style = True
        self.__need_sknr_style = True
        self.__need_sknr_full_style = True
        self.__need_sknr_full_lines_style = True
        self.__need_kv_style = True
        self.__need_kv_lines_style = True

    @property
    def ugeom(self) -> Optional[QgsVectorLayer]:
        return self.__ugeom

    @property
    def tax_sknr_geom(self) -> Optional[QgsVectorLayer]:
        return self.__sknr

    @property
    def tax_sknr_full_geom(self) -> Optional[QgsVectorLayer]:
        return self.__sknr_full

    @property
    def tax_sknr_full_geom_lines(self) -> Optional[QgsVectorLayer]:
        return self.__sknr_full_lines

    @property
    def tax_kv_geom(self) -> Optional[QgsVectorLayer]:
        return self.__kv

    @property
    def tax_kv_lines_geom(self) -> Optional[QgsVectorLayer]:
        return self.__kv_lines

    def sheck_existing_for_all(self) -> None:
        # Проверка всех слоев на существование и не удалены ли они
        # если слой не существует или удален ему присовится None, иначе слой присвоится сам себе

        self.__ugeom = check_layer_exists(self.__ugeom)
        self.__sknr = check_layer_exists(self.__sknr)
        self.__sknr_full = check_layer_exists(self.__sknr_full)
        self.__sknr_full_lines = check_layer_exists(self.__sknr_full_lines)
        self.__kv = check_layer_exists(self.__kv)
        self.__kv_lines = check_layer_exists(self.__kv_lines)

    def set_styles(self, ugeom_style_path: str, sknr_style_path: str, sknr_full_style_path: str,
                   sknr_full_lines_style_path: str, kv_style_path: str, kv_lines_path: str) -> None:
        # Установка стилей для всех слоев

        set_style(self.__ugeom, self.__need_ugeom_style, ugeom_style_path)
        set_style(self.__sknr, self.__need_sknr_style, sknr_style_path)
        set_style(self.__sknr_full, self.__need_sknr_full_style, sknr_full_style_path)
        set_style(self.__sknr_full_lines, self.__need_sknr_full_lines_style, sknr_full_lines_style_path)
        set_style(self.__kv, self.__need_kv_style, kv_style_path)
        set_style(self.__kv_lines, self.__need_kv_lines_style, kv_lines_path)

    def load_data(self, active_order: QgsFeature) -> None:
        # подготовка и загрузка слоев из заявки (active_order)

        # QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(), 'order_id', active_order["id"])

        # TODO подумать насчет проекции карты и масштаба (см. Atlas)

        self.sheck_existing_for_all()

        self.__uri.setDataSource(
            aSchema="public",
            aTable="ugeom",
            aGeometryColumn="geom",
            aSql="id = {}".format(active_order["uid"]),
            aKeyColumn="id")

        self.__ugeom, self.__need_ugeom_style = load_layer_from_db(self.__ugeom, self.__uri, self.ugeom_name)

        order_data = active_order["data"]

        # контейнеры для id выделов и для наборов (sri, mu, gir, kv) из json
        sknr_ids = set()
        sri_mu_gir_kv = set()

        # парсим выдела из json, и если что-то из keys не сущетсвует, то пропускаем выдел
        keys = ["id", "sri", "mu", "gir", "kv"]
        for item in order_data:
            not_exist = [item.get(key, None) is None for key in keys]
            if not any(not_exist):
                sknr_ids.add(item["id"])
                sri_mu_gir_kv.add((item["sri"], item["mu"], item["gir"], item["kv"]))

        self.__uri.setDataSource(
            aSchema="",
            aTable="(" + "SELECT t.id, t.sri, t.mu, t.gir, t.kv, t.sknr, t.zk, "
                         "st_intersection(ST_MakeValid(t.geom), ST_MakeValid(u.geom)) as geom "
                         "FROM tax as t, ugeom as u WHERE (u.id = {}) AND ({})"
                .format(active_order["uid"], " OR ".join(["t.id = {}".format(sknr_id) for sknr_id in sknr_ids])) + ")",
            aGeometryColumn="geom",
            # aSql=" OR ".join(["id = {}".format(sknr_id) for sknr_id in sknr_ids]),
            aKeyColumn="id")

        self.__sknr, self.__need_sknr_style = load_layer_from_db(self.__sknr, self.__uri, self.sknr_name)

        where_clause = " OR ".join(
            ["(sri = {} AND mu = {} AND gir = {} AND kv = {})".format(sri, mu, gir, kv)
             for sri, mu, gir, kv in sri_mu_gir_kv])

        self.__uri.setDataSource(
            aSchema="",
            aTable="(" + "SELECT id, sri, mu, gir, kv, zk, sknr, ST_MakeValid(geom) as geom FROM public.tax WHERE {}"
                .format(where_clause) + ")",
            aGeometryColumn="geom",
            # aSql=where_clause,
            aKeyColumn="id")

        self.__sknr_full, self.__need_sknr_full_style = load_layer_from_db(self.__sknr_full, self.__uri,
                                                                           self.sknr_full_name)

        temp_layer = processing.run(self.__dlg.model(), {
            'INPUT': self.__sknr_full,
            'native:dissolve_1:OUTPUT': 'TEMPORARY_OUTPUT'})['native:dissolve_1:OUTPUT']

        self.__sknr_full_lines, self.__need_sknr_full_lines_style = load_layer_from_layer(
            self.__sknr_full_lines, temp_layer, self.sknr_full_lines_name)

        print(where_clause)

        self.__uri.setDataSource(
            aSchema="",
            aTable="(" + '''WITH first as (
                            SELECT id, sri, mu, gir, kv, ST_MakeValid(geom) as geom
                            FROM public.tax
                            WHERE
                               {}                        ),
                        second as (
                            SELECT Max(id) as id, sri, mu, gir, kv, st_union(geom) as geom
                            FROM first
                            GROUP BY sri, mu, gir, kv
                        )
                        SELECT sc.id, sc.sri, mu, gir, kv, sc.geom,
                               fs.name as federal_subject, f."LN_NAME" as forestry, s."ULN_NAME" as subforestry,
                               o.id as order_id, o.timestamp as order_date
                        FROM second as sc
                            LEFT JOIN federal_subject fs on sc.sri = fs.federal_subject_id
                            LEFT JOIN forestry f on sc.sri = f."KOD_SUB" AND sc.mu = f."KOD_LN"
    LEFT JOIN subforestry s on sc.sri = s."KOD_SUB" AND sc.mu = s."KOD_LN" AND sc.gir = s."KOD_ULN"
    LEFT JOIN ordering o on o.id = {}
    '''.format(where_clause, active_order["id"]) + ")",
            aGeometryColumn="geom",
            aKeyColumn="id")

        self.__kv, self.__need_kv_style = load_layer_from_db(self.__kv, self.__uri, self.kv_name)

        temp_layer = processing.run(self.__dlg.model(), {
            "INPUT": self.__kv,
            'native:dissolve_1:OUTPUT': 'TEMPORARY_OUTPUT'})['native:dissolve_1:OUTPUT']

        self.__kv_lines, self.__need_kv_lines_style = load_layer_from_layer(
            self.__kv_lines, temp_layer, self.kv_lines_name)











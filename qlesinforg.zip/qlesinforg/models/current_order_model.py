import os

import processing
from processing.modeler.ModelerDialog import ModelerDialog
from qgis.core import QgsDataSourceUri, QgsFeature, QgsVectorLayer, QgsProject, QgsDataProvider, \
    QgsExpressionContextUtils


# from qgis.core.additions import processing


class NoLayerException(Exception):
    pass


class ActiveOrder:
    ugeom_name = "Вектор заказа"
    sknr_name = "Категории"
    sknr_full_name = "Выдела"
    sknr_full_lines_name = "Выдела (границы)"
    kv_name = "Квартала"
    kv_lines_name = "Квартала (границы)"

    def __init__(self, connection, plugin_dir):
        self.uri = QgsDataSourceUri()
        self.uri.setConnection(**connection)

        self.plugin_dir = plugin_dir

        self.dlg = ModelerDialog()
        self.dlg.loadModel(os.path.join(self.plugin_dir, r"qgis_models", "polygons_to_lines.model3"))

        self.__ugeom = None
        self.__sknr = None
        self.__sknr_full = None
        self.__sknr_full_lines = None
        self.__kv = None
        self.__kv_lines = None

        self.__need_ugeom_style = True
        self.__need_sknr_style = True
        self.__need_sknr_full_style = True
        self.__need_sknr_full_lines_style = True
        self.__need_kv_style = True
        self.__need_kv_lines_style = True

    @property
    def ugeom(self):
        return self.__ugeom

    @property
    def tax_sknr_geom(self):
        return self.__sknr

    @property
    def tax_sknr_full_geom(self):
        return self.__sknr_full

    @property
    def tax_sknr_full_geom_lines(self):
        return self.__sknr_full_lines

    @property
    def tax_kv_geom(self):
        return self.__kv

    @property
    def tax_kv_lines_geom(self):
        return self.__kv_lines

    def sheck_existing(self):

        if self.__ugeom is not None:
            try:
                self.__ugeom.isValid()
            except RuntimeError:
                self.__ugeom = None

        if self.__sknr is not None:
            try:
                self.__sknr.isValid()
            except RuntimeError:
                self.__sknr = None

        if self.__sknr_full is not None:
            try:
                self.__sknr_full.isValid()
            except RuntimeError:
                self.__sknr_full = None

        if self.__sknr_full_lines is not None:
            try:
                self.__sknr_full_lines.isValid()
            except RuntimeError:
                self.__sknr_full_lines = None

        if self.__kv is not None:
            try:
                self.__kv.isValid()
            except RuntimeError:
                self.__kv = None

        if self.__kv_lines is not None:
            try:
                self.__kv_lines.isValid()
            except RuntimeError:
                self.__kv_lines = None

    def set_styles(self, ugeom_style_path, sknr_style_path, sknr_full_style_path,
                   sknr_full_lines_style_path, kv_style_path, kv_lines_path):

        if self.__need_ugeom_style:
            self.__ugeom.loadNamedStyle(ugeom_style_path)

        if self.__need_sknr_style:
            self.__sknr.loadNamedStyle(sknr_style_path)

        if self.__need_sknr_full_style:
            self.__sknr_full.loadNamedStyle(sknr_full_style_path)

        if self.__need_sknr_full_lines_style:
            self.__sknr_full_lines.loadNamedStyle(sknr_full_lines_style_path)

        if self.__need_kv_style:
            self.__kv.loadNamedStyle(kv_style_path)

        if self.__need_kv_lines_style:
            self.__kv_lines.loadNamedStyle(kv_lines_path)

    def load_data(self, active_order: QgsFeature):

        QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(), 'order_id', active_order["id"])
        QgsExpressionContextUtils.setProjectVariable(QgsProject.instance(), 'order_date', active_order["timestamp"])

        self.sheck_existing()

        self.uri.setDataSource(
            aSchema="public",
            aTable="ugeom",
            aGeometryColumn="geom",
            aSql="id = {}".format(active_order["uid"]),
            aKeyColumn="id")

        if self.__ugeom is None:
            self.__ugeom = QgsVectorLayer(self.uri.uri(), self.ugeom_name, "postgres")
            self.__need_ugeom_style = True
        else:
            self.__ugeom.setDataSource(self.uri.uri(), self.ugeom_name, "postgres",
                                       QgsDataProvider.ProviderOptions())
            self.__ugeom.updateExtents()
            self.__need_ugeom_style = False

        # self.__need_loading_ugeom_style = self.load_layer(self.__ugeom, self.uri, self.ugeom_layer_name)

        order_data = active_order["data"]

        sknr_ids = set()
        sri_mu_gir_kv = set()

        keys = ["id", "sri", "mu", "gir", "kv"]
        for item in order_data:
            not_exist = [item[key] is None for key in keys]
            if not any(not_exist):
                sknr_ids.add(item["id"])
                sri_mu_gir_kv.add((item["sri"], item["mu"], item["gir"], item["kv"]))

        self.uri.setDataSource(
            aSchema="",
            aTable="(" + "SELECT t.id, t.sri, t.mu, t.gir, t.kv, t.sknr, t.zk, "
                         "st_intersection(ST_MakeValid(t.geom), ST_MakeValid(u.geom)) as geom "
                         "FROM tax as t, ugeom as u WHERE (u.id = {}) AND ({})".format(
                active_order["uid"],
                " OR ".join(["t.id = {}".format(sknr_id) for sknr_id in sknr_ids])) + ")",
            aGeometryColumn="geom",
            # aSql=" OR ".join(["id = {}".format(sknr_id) for sknr_id in sknr_ids]),
            aKeyColumn="id")

        if self.__sknr is None:
            self.__sknr = QgsVectorLayer(self.uri.uri(), self.sknr_name, "postgres")
            self.__need_sknr_style = True
        else:
            self.__sknr.setDataSource(self.uri.uri(), self.sknr_name, "postgres",
                                      QgsDataProvider.ProviderOptions())
            self.__sknr.updateExtents()
            self.__need_sknr_style = False

        # self.__need_loading_tax_sknr_geom_style = self.load_layer(self.__tax_sknr_geom, self.uri, self.tax_sknr_layer_name)

        where_clause = " OR ".join(
            ["(sri = {} AND mu = {} AND gir = {} AND kv = {})".format(sri, mu, gir, kv)
             for sri, mu, gir, kv in sri_mu_gir_kv])

        self.uri.setDataSource(
            aSchema="",
            aTable="(" + "SELECT id, sri, mu, gir, kv, zk, sknr, ST_MakeValid(geom) as geom FROM public.tax WHERE {}".format(where_clause) + ")",
            aGeometryColumn="geom",
            # aSql=where_clause,
            aKeyColumn="id")

        if self.__sknr_full is None:
            self.__sknr_full = QgsVectorLayer(self.uri.uri(), self.sknr_full_name, "postgres")
            self.__need_sknr_full_style = True
        else:
            self.__sknr_full.setDataSource(self.uri.uri(), self.sknr_full_name, "postgres",
                                           QgsDataProvider.ProviderOptions())
            self.__sknr_full.updateExtents()
            self.__need_sknr_full_style = False

        temp_layer = processing.run(self.dlg.model(), {
            'INPUT': self.__sknr_full,
            'native:dissolve_1:OUTPUT': 'TEMPORARY_OUTPUT'})['native:dissolve_1:OUTPUT']

        if self.__sknr_full_lines is None:
            self.__sknr_full_lines = temp_layer
            self.__sknr_full_lines.setName(self.sknr_full_lines_name)
            self.__need_sknr_full_lines_style = True
        else:
            self.__sknr_full_lines.setDataSource(temp_layer.source(), self.sknr_full_lines_name,
                                                          "memory", QgsDataProvider.ProviderOptions())

            self.__sknr_full_lines.dataProvider().addFeatures(temp_layer.getFeatures())
            self.__sknr_full_lines.updateExtents()
            self.__need_sknr_full_lines_style = False

        # self.__need_loading_tax_sknr_full_geom_style = self.load_layer(self.__tax_sknr_full_geom, self.uri, self.tax_sknr_full_layer_name)

        self.uri.setDataSource(
            aSchema="",
            # aTable="(" + f"SELECT Max(id) as id, sri, mu, gir, kv, st_union(geom) as geom FROM "
            #              "(SELECT id, sri, mu, gir, kv, ST_MakeValid(geom) as geom FROM public.tax WHERE {}) as subquery"
            #              " GROUP BY sri, mu, gir, kv".format(where_clause) + ")",
            aTable="(" + '''WITH first as (
                            SELECT id, sri, mu, gir, kv, ST_MakeValid(geom) as geom
                            FROM public.tax
                            WHERE
                               {}                        ),
                        second as (
                            SELECT Max(id) as id, sri, mu, gir, kv, st_union(geom) as geom
                            FROM first
                            GROUP BY sri, mu, gir, kv
                        )
                        SELECT sc.id, sri, mu, gir, kv, sc.geom,
                               fs.name as federal_subject, f."LN_NAME" as forestry, s."ULN_NAME" as subforestry
                        FROM second as sc
                            LEFT JOIN federal_subject fs on sc.sri = fs.fid
                            LEFT JOIN forestry f on sc.sri = f."KOD_SUB" AND sc.mu = f."KOD_LN"
    LEFT JOIN subforestry s on sc.sri = s."KOD_SUB" AND sc.mu = s."KOD_LN" AND sc.gir = s."KOD_ULN"'''.format(where_clause) + ")",
            aGeometryColumn="geom",
            aKeyColumn="id")

        if self.__kv is None:
            self.__kv = QgsVectorLayer(self.uri.uri(), self.kv_name, "postgres")
            self.__need_kv_style = True
        else:
            self.__kv.setDataSource(self.uri.uri(), self.kv_name, "postgres",
                                    QgsDataProvider.ProviderOptions())
            self.__kv.updateExtents()
            self.__need_kv_style = False

        temp_layer = processing.run(self.dlg.model(), {
            "INPUT": self.__kv,
            'native:dissolve_1:OUTPUT': 'TEMPORARY_OUTPUT'})['native:dissolve_1:OUTPUT']

        if self.__kv_lines is None:
            self.__kv_lines = temp_layer
            self.__kv_lines.setName(self.kv_lines_name)
            self.__need_kv_lines_style = True
        else:
            self.__kv_lines.setDataSource(temp_layer.source(), self.kv_lines_name,
                                                          "memory", QgsDataProvider.ProviderOptions())

            self.__kv_lines.dataProvider().addFeatures(temp_layer.getFeatures())
            self.__kv_lines.updateExtents()
            self.__need_kv_lines_style = False

        # self.__need_loading_tax_kv_geom_style = self.load_layer(self.__tax_kv_geom, self.uri, self.tax_kv_Layer_name)

    # @staticmethod
    # def load_layer(layer, uri, layer_name):
    #     if layer is None:
    #         layer = QgsVectorLayer(uri.uri(), layer_name, "postgres")
    #         return True
    #     else:
    #         layer.setDataSource(uri.uri(), layer_name, "postgres",
    #                             QgsDataProvider.ProviderOptions())
    #         layer.updateExtents()
    #         return False

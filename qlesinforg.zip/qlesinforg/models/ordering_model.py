import os
from typing import Dict, Optional, List, Any

from PyQt5 import QtGui, QtCore
from PyQt5.QtCore import QAbstractTableModel, Qt, QDateTime, QModelIndex
from qgis.core import QgsVectorLayer, QgsFeature, QgsDataSourceUri, QgsDataProvider

# пути до иконок
icon_false_work = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "false_work.png"))
icon_false = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "false.png"))
icon_true_work = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "true_work.png"))
icon_true = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "true.png"))
icon_work = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "work.png"))
icon_empty = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "empty.png"))


class OrderingModel(QAbstractTableModel):
    # модель для работы с заявками

    # статусы заявок
    STATUS_TEXTPART = 4
    STATUS_MAPPART = 5
    STATUS_REJECTED = 6

    signal_active_order = QtCore.pyqtSignal(bool)
    signal_have_changes = QtCore.pyqtSignal(bool)
    signal_data_reloaded = QtCore.pyqtSignal()
    signal_data_start_reload = QtCore.pyqtSignal()

    def __init__(self, connection: Dict[str, str]) -> None:
        super().__init__()

        # статусы, которые попадут в модель
        self.__statuses_for_query = [str(self.STATUS_TEXTPART)]

        self.__normal_datasourse = {"aSchema": "public",
                                    "aTable": "ordering",
                                    "aGeometryColumn": None,
                                    "aSql": "status IN ({})".format(
                                        ",".join(self.__statuses_for_query)),
                                    "aKeyColumn": "id"}
        # self.__normal_datasourse = {"aSchema": "public",
        #                             "aTable": "ordering",
        #                             "aGeometryColumn": None,
        #                             "aSql": "timestamp >= '2021-02-08'::date",
        #                             "aKeyColumn": "id"}
        # флаг того, производится ли обычный запрос заявок, либо с добавлением редактируемой заявки
        # normal_datasourse разный для этих случаев
        self.normal_datasourse_setted = True

        self.__uri = QgsDataSourceUri()
        self.__uri.setConnection(**connection)
        self.__uri.setDataSource(**self.__normal_datasourse)

        self.__ordering_layer = QgsVectorLayer(self.__uri.uri(), "ordering", "postgres")
        # features из слоя перегоняем в список и далее работаем со списком (так выше происзводительность)
        self.__local_features: List[QgsFeature] = list(self.__ordering_layer.getFeatures())

        self.__fcount = len(self.__local_features)
        self.__ccount = self.__ordering_layer.fields().count()
        self.__fields = self.__ordering_layer.fields().names()

        # контейнер для измененных features
        self.__changed_features = set()
        # текущая (редактируемая) заявка
        self.__activeOrder = None
        self.__activeOrder: QgsFeature

        self.__key_field_index = self.__ordering_layer.fields().indexFromName('timestamp')
        self.__data_field_index = self.__ordering_layer.fields().indexFromName('data')

        self.signal_have_changes.emit(False)
        self.signal_active_order.emit(False)

    @property
    def ordering_layer(self) -> Optional[QgsVectorLayer]:
        return self.__ordering_layer

    @property
    def key_field_index(self) -> int:
        return self.__key_field_index

    @property
    def data_field_index(self) -> int:
        return self.__data_field_index

    @property
    def local_features(self) -> List[QgsFeature]:
        return self.__local_features

    @property
    def active_order(self) -> Optional[QgsFeature]:
        return self.__activeOrder

    def data(self, index: QModelIndex, role: int) -> Any:
        # вывод информации из модели в зависимости от роли

        if role == Qt.DisplayRole:
            # отображение информации

            # проверка, чтобы не выводить информацию из json, она очень тяжелая
            if index.column() != self.__data_field_index:

                value = self.__local_features[index.row()].attributes()[index.column()]

                if isinstance(value, QDateTime):
                    return value.toPyDateTime().strftime("%Y.%m.%d %H.%M.%S")
                else:
                    return str(value)

            else:
                return ""

        if role == Qt.ToolTipRole:
            # подробные данные и заявке при наведении
            return """<table>
                      <tr>
                        <td>Заявка</td>
                        <td>{id}</td> 
                      </tr>
                      <tr>
                        <td>Дата</td>
                        <td>{date}</td>
                      </tr>
                      <tr>
                        <td>Статус</td>
                        <td>{status}</td>
                      </tr>
                    </table>""" \
                .format(id=self.__local_features[index.row()]["id"],
                        date=self.__local_features[index.row()]["timestamp"].toPyDateTime().strftime(
                            "%Y.%m.%d %H.%M.%S"),
                        status=self.__local_features[index.row()]["status"])

        if role == Qt.DecorationRole and index.column() == self.__key_field_index:
            # отображение значков

            value = self.__local_features[index.row()]["status"]

            # TODO Подумать. Может как-то вынести self.__local_features[index.row()]["id"] == self.__activeOrder["id"] ?

            if value == self.STATUS_REJECTED:
                if self.__activeOrder:
                    if self.__local_features[index.row()]["id"] == self.__activeOrder["id"]:
                        return icon_false_work
                    else:
                        return icon_false
                else:
                    return icon_false

            elif value == self.STATUS_MAPPART:
                if self.__activeOrder:
                    if self.__local_features[index.row()]["id"] == self.__activeOrder["id"]:
                        return icon_true_work
                    else:
                        return icon_true
                else:
                    return icon_true

            elif value == self.STATUS_TEXTPART:
                if self.__activeOrder:
                    if self.__local_features[index.row()]["id"] == self.__activeOrder["id"]:
                        return icon_work
                    else:
                        return icon_empty
                else:
                    return icon_empty

    def rowCount(self, index: QModelIndex) -> int:
        return self.__fcount

    def columnCount(self, index: QModelIndex) -> int:
        return self.__ccount

    def headerData(self, section: int, orientation: int, role: int) -> Any:
        if role == Qt.DisplayRole:
            if orientation == Qt.Horizontal:
                return str(self.__fields[section])

    def reloadData(self) -> None:
        # перезапрос данных из БД

        self.signal_data_start_reload.emit()

        if isinstance(self.__activeOrder, QgsFeature):

            # TODO сделать так, чтобы поле с json не выгружалось в таблицу с заказами
            #  а выгружать его потом для конкретной заявки в current_order_model
            #  сделать это обязательно!

            # запрос заявок с добавлением редактируемой заявки
            datasourse_with_active_order = {"aSchema": "public",
                                            "aTable": "ordering",
                                            "aGeometryColumn": None,
                                            "aSql": "(status IN ({})) OR (id = {})".format(
                                                ",".join(self.__statuses_for_query), self.__activeOrder["id"]),
                                            "aKeyColumn": "id"}

            self.__uri.setDataSource(**datasourse_with_active_order)

            self.__ordering_layer.setDataSource(self.__uri.uri(), "ordering", "postgres",
                                                QgsDataProvider.ProviderOptions())

            # TODO работает не корректно добавление редактируемой заявки обратно в запрос. Подумать, переделать

            # заменяем редактирумую заявку на ее же, но из базы
            for ordering_feat in self.__ordering_layer.getFeatures():
                if self.__activeOrder["id"] == ordering_feat["id"]:
                    self.__activeOrder = ordering_feat
                    break

            self.normal_datasourse_setted = False
        else:
            # запрос заявок с без добавления редактируемой заявки
            if self.normal_datasourse_setted:
                # если источник данных установлен нормальный, то просто обновляем дата провайдер
                self.__ordering_layer.dataProvider().reloadData()
            else:
                # если источник данных установлен был с добавлением редактирумой заявки,
                # то устанавливаем обычный источник данных (без добавления)
                self.__uri.setDataSource(**self.__normal_datasourse)
                self.__ordering_layer.setDataSource(self.__uri.uri(), "ordering", "postgres",
                                                    QgsDataProvider.ProviderOptions())
                self.normal_datasourse_setted = True

        self.__local_features = list(self.__ordering_layer.getFeatures())
        self.__fcount = len(self.__local_features)

        self.__ccount = self.__ordering_layer.fields().count()
        self.__fields = self.__ordering_layer.fields().names()

        self.__changed_features = set()

        self.signal_have_changes.emit(False)
        # self.signal_active_order.emit(False)
        self.signal_data_reloaded.emit()

    def send_data(self) -> None:
        # отправка данных в БД, но только если статусы локальной заявки и заявки в БД не совпадают
        for local_feat in self.__changed_features:

            layer_feat = self.__ordering_layer.getFeature(local_feat.id())

            if local_feat["status"] != layer_feat["status"]:
                self.set_value(local_feat.id(), "status", local_feat["status"])

        self.__changed_features = set()
        self.signal_have_changes.emit(False)

    def set_value(self, id: int, field_name: str, value: Any) -> None:
        # установка значения
        self.__ordering_layer.startEditing()
        self.__ordering_layer.changeAttributeValue(id, self.__ordering_layer.fields().indexFromName(field_name), value)
        self.__ordering_layer.commitChanges()

    @active_order.setter
    def active_order(self, feat: Optional[QgsFeature]) -> None:
        # установка активной (редактирумой) заявки
        self.__activeOrder = feat

        if isinstance(feat, QgsFeature):
            self.signal_active_order.emit(True)
        else:
            self.signal_active_order.emit(False)

    def show_info(self) -> None:
        print("\n" + "-" * 10 + "Информация из модели" + "-" * 10)

        print("_layer.getureCount() ", self.__ordering_layer.featureCount())
        print("len(self.__local_features)", len(self.__local_features))
        print("_fcount", self.__fcount)
        print("_ccount", self.__ccount)
        print("len(self._changed_features)", len(self.__changed_features))
        if self.__activeOrder:
            print("self.__activeOrder.attributes()", self.__activeOrder.id(), self.__activeOrder["id"],
                  self.__activeOrder["timestamp"])
        print("self.__key_field_index", self.__key_field_index)

        print("for feat in self.__local_features")
        for feat in self.__local_features:
            if feat:
                print(feat.id(), feat["id"], feat["timestamp"])
            else:
                print("-------")

    def set_status(self, status: int) -> None:
        # установка нового статуса для редактирумой заявки и доабвление ее в контейнер с измененными заявками
        if self.__activeOrder["status"] != status:
            self.__activeOrder["status"] = status

            self.__changed_features.add(self.__activeOrder)
            self.signal_have_changes.emit(True)

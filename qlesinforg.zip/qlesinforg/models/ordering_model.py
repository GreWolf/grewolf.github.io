import os

from PyQt5.QtCore import QAbstractTableModel, Qt, QDateTime
from qgis.core import QgsVectorLayer, QgsFeature, QgsDataSourceUri, QgsDataProvider
from PyQt5 import QtGui, QtCore

icon_false_work = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "false_work.png"))
icon_false = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "false.png"))
icon_true_work = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "true_work.png"))
icon_true = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "true.png"))
icon_work = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "work.png"))
icon_empty = QtGui.QIcon(os.path.join(os.path.dirname(__file__), "ordering_model_png", "empty.png"))


class OrderingModel(QAbstractTableModel):
    STATUS_TEXTPART = 4
    STATUS_MAPPART = 5
    STATUS_REJECTED = 6

    signal_active_order = QtCore.pyqtSignal(bool)
    signal_have_changes = QtCore.pyqtSignal(bool)
    signal_data_reloaded = QtCore.pyqtSignal()
    signal_data_start_reload = QtCore.pyqtSignal()

    def __init__(self, connection):
        super().__init__()
        # self.statuses_for_query = [str(self.STATUS_TEXTPART), str(self.STATUS_MAPPART), str(self.STATUS_REJECTED)]
        self.statuses_for_query = [str(self.STATUS_TEXTPART)]

        self.normal_datasourse = {"aSchema": "public",
                                  "aTable": "ordering",
                                  "aGeometryColumn": None,
                                  "aSql": "status IN ({})".format(
                                      ",".join(self.statuses_for_query)),
                                  "aKeyColumn": "id"}

        self.normal_datasourse_setted = True

        self.uri = QgsDataSourceUri()

        self.uri.setConnection(**connection)

        self.uri.setDataSource(**self.normal_datasourse)

        self.__ordering_layer = QgsVectorLayer(self.uri.uri(), "ordering", "postgres")

        self.__local_features = list(self.__ordering_layer.getFeatures())

        self.__fcount = len(self.__local_features)
        self.__ccount = self.__ordering_layer.fields().count()
        self.__fields = self.__ordering_layer.fields().names()

        self.__changed_features = set()
        self.__activeOrder = None
        self.__activeOrder: QgsFeature

        self.__key_field_index = self.__ordering_layer.fields().indexFromName('timestamp')
        self.__data_field_index = self.__ordering_layer.fields().indexFromName('data')

        self.signal_have_changes.emit(False)
        self.signal_active_order.emit(False)

    @property
    def ordering_layer(self):
        return self.__ordering_layer

    @property
    def key_field_index(self):
        return self.__key_field_index

    @property
    def data_field_index(self):
        return self.__data_field_index

    @property
    def local_features(self):
        return self.__local_features

    @property
    def active_order(self):
        return self.__activeOrder

    def data(self, index, role):
        if role == Qt.DisplayRole:

            if index.column() != self.__data_field_index:

                value = self.__local_features[index.row()].attributes()[index.column()]
                value: QDateTime

                if isinstance(value, QDateTime):
                    return value.toPyDateTime().strftime("%Y.%m.%d %H.%M.%S")
                else:
                    return str(value)

            else:
                return ""

        if role == Qt.DecorationRole and index.column() == self.__key_field_index:
            value = self.__local_features[index.row()]["status"]

            # TODO Подумать. Может как-то вынести self.__local_features[index.row()]["id"] == self.__activeOrder["id"] ?

            if value == self.STATUS_REJECTED:
                if self.__activeOrder:
                    if self.__local_features[index.row()]["id"] == self.__activeOrder["id"]:
                        return icon_false_work
                    else:
                        return icon_false
                else:
                    return icon_false

            elif value == self.STATUS_MAPPART:
                if self.__activeOrder:
                    if self.__local_features[index.row()]["id"] == self.__activeOrder["id"]:
                        return icon_true_work
                    else:
                        return icon_true
                else:
                    return icon_true

            elif value == self.STATUS_TEXTPART:
                if self.__activeOrder:
                    if self.__local_features[index.row()]["id"] == self.__activeOrder["id"]:
                        return icon_work
                    else:
                        return icon_empty
                else:
                    return icon_empty

    def rowCount(self, index):
        return self.__fcount

    def columnCount(self, index):
        return self.__ccount

    def headerData(self, section, orientation, role):
        if role == Qt.DisplayRole:
            if orientation == Qt.Horizontal:
                return str(self.__fields[section])

    def reloadData(self):
        self.signal_data_start_reload.emit()

        if isinstance(self.__activeOrder, QgsFeature):
            print("Изменяю запрос на запрос с активным заказом")
            datasourse_with_active_order = {"aSchema": "public",
                                            "aTable": "ordering",
                                            "aGeometryColumn": None,
                                            "aSql": "(status IN ({})) OR (id = {})".format(
                                                ",".join(self.statuses_for_query), self.__activeOrder["id"]),
                                            "aKeyColumn": "id"}

            self.uri.setDataSource(**datasourse_with_active_order)

            self.__ordering_layer.setDataSource(self.uri.uri(), "ordering", "postgres",
                                                QgsDataProvider.ProviderOptions())

            # self.__activeOrder = self.__ordering_layer.getFeature(self.__activeOrder.id())
            for ordering_feat in self.__ordering_layer.getFeatures():
                if self.__activeOrder["id"] == ordering_feat["id"]:
                    self.__activeOrder = ordering_feat
                    break

            self.normal_datasourse_setted = False
        else:

            if self.normal_datasourse_setted:
                print("Просто перезагружаю")
                self.__ordering_layer.dataProvider().reloadData()
            else:

                print("Изменяю запрос на обычный запрос")
                self.uri.setDataSource(**self.normal_datasourse)
                self.__ordering_layer.setDataSource(self.uri.uri(), "ordering", "postgres",
                                                    QgsDataProvider.ProviderOptions())
                self.normal_datasourse_setted = True

        self.__local_features = list(self.__ordering_layer.getFeatures())

        self.__fcount = len(self.__local_features)

        self.__ccount = self.__ordering_layer.fields().count()
        self.__fields = self.__ordering_layer.fields().names()

        self.__changed_features = set()

        self.signal_have_changes.emit(False)
        # self.signal_active_order.emit(False)
        self.signal_data_reloaded.emit()

    def send_data(self):
        for local_feat in self.__changed_features:

            layer_feat = self.__ordering_layer.getFeature(local_feat.id())

            if local_feat["status"] != layer_feat["status"]:
                self.set_value(local_feat.id(), "status", local_feat["status"])

        self.__changed_features = set()
        self.signal_have_changes.emit(False)

    def set_value(self, id, field_name, value):
        self.__ordering_layer.startEditing()
        self.__ordering_layer.changeAttributeValue(id, self.__ordering_layer.fields().indexFromName(field_name), value)
        self.__ordering_layer.commitChanges()

    @active_order.setter
    def active_order(self, feat):
        self.__activeOrder = feat

        if isinstance(feat, QgsFeature):
            self.signal_active_order.emit(True)
        else:
            self.signal_active_order.emit(False)

    def show_info(self):
        print("\n" + "-" * 10 + "Информация из модели" + "-" * 10)

        print("_layer.getureCount() ", self.__ordering_layer.featureCount())
        print("len(self.__local_features)", len(self.__local_features))
        print("_fcount", self.__fcount)
        print("_ccount", self.__ccount)
        print("len(self._changed_features)", len(self.__changed_features))
        if self.__activeOrder:
            print("self.__activeOrder.attributes()", self.__activeOrder.id(), self.__activeOrder["id"],
                  self.__activeOrder["timestamp"])
        print("self.__key_field_index", self.__key_field_index)

        print("for feat in self.__local_features")
        for feat in self.__local_features:
            if feat:
                print(feat.id(), feat["id"], feat["timestamp"])
            else:
                print("-------")

    def set_status(self, status):
        if self.__activeOrder["status"] != status:
            self.__activeOrder["status"] = status

            self.__changed_features.add(self.__activeOrder)
            self.signal_have_changes.emit(True)

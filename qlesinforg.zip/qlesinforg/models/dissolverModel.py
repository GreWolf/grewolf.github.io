"""
Model exported as python.
Name : Prepare point 4
Group :
With QGIS : 31200
"""

import processing
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterCrs,
                       QgsProcessingParameterExpression,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterField,
                       QgsProcessingParameterString,
                       QgsProcessingParameterBoolean,)

from qgis.PyQt.QtCore import (
    QCoreApplication, QT_TR_NOOP
)

class dissolverModel(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString('POINTFIELD', 'POINTFIELD', multiLine=False, defaultValue='point_id'))
        self.addParameter(QgsProcessingParameterString('UCHFIELD', 'UCHFIELD', multiLine=False, defaultValue='uch_id'))
        self.addParameter(QgsProcessingParameterField('DROPFIELDSKVMK', 'DROPFIELDSKVMK', type=QgsProcessingParameterField.Any, parentLayerParameterName='INPUT', allowMultiple=True, defaultValue='Sri_2;Mu_2;Gir_2;Mk_2;vertex_index_2;vertex_part_2;vertex_part_ring_2;vertex_part_index_2;distance_2;angle_2;x_2;y_2;link_id_2;link_id;vertex_index;vertex_part;vertex_part_ring;vertex_part_index;distance;angle'))
        self.addParameter(QgsProcessingParameterField('GROUPFIELDS', 'GROUPFIELDS', type=QgsProcessingParameterField.Any, parentLayerParameterName='INPUT', allowMultiple=True, defaultValue='Sri;Mu;Gir;Mk'))
        self.addParameter(QgsProcessingParameterField('FIELDSFORDELDUPLICATES', 'FIELDSFORDELDUPLICATES', type=QgsProcessingParameterField.Any, parentLayerParameterName='INPUT', allowMultiple=True, defaultValue='Sri;Mu;Gir;Mk;x;y'))
        # self.addParameter(QgsProcessingParameterVectorLayer('INPUT', 'INPUT', types=[QgsProcessing.TypeVectorAnyGeometry], defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSource('INPUT', 'INPUT', types=[QgsProcessing.TypeVectorAnyGeometry], defaultValue=None))
        self.addParameter(QgsProcessingParameterField('DROPFIELDSMK', 'DROPFIELDSMK', type=QgsProcessingParameterField.Any, parentLayerParameterName='INPUT', allowMultiple=True, defaultValue='Kv;OBJECTID;fid_1;Lr;Zkz;Ugir;Mu1;Rel;Sknr;Pl;Zk;Vmr;Amz1;Akl;Agr;Bon;Mtip;Dtg;Skal1;Tur1h1;Kl;Strata;Izm;layer;Deleted;Ð__Ð__Ð___;Shape_Leng;Shape_Area'))
        self.addParameter(QgsProcessingParameterExpression('LINKEXPRESSION', 'LINKEXPRESSION', parentLayerParameterName='', defaultValue='\"Sri\" || \' \' || \"Mu\" || \' \' || \"Gir\" || \' \' || \"Mk\" || \' \' || \"x\"  || \' \' ||  \"y\" '))
        self.addParameter(QgsProcessingParameterCrs('PROJECTION', 'PROJECTION', defaultValue='EPSG:4326'))
        self.addParameter(QgsProcessingParameterExpression('SORTEXPRESSIONKV', 'SORTEXPRESSIONKV', parentLayerParameterName='', defaultValue='\"Sri\" || \' \' || \"Mu\" || \' \' || \"Gir\" || \' \' || \"Mk\"'))
        self.addParameter(QgsProcessingParameterExpression('SORTEXPRESSIONMK', 'SORTEXPRESSIONMK', parentLayerParameterName='', defaultValue='y_max($geometry)'))
        self.addParameter(QgsProcessingParameterFeatureSink('POLYGONS', 'POLYGONS', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('POINTS', 'POINTS', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterBoolean('SPLITMULTIPART', 'SPLITMULTIPART', defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean('DELETEGROUPDUPLICATES', 'DELETEGROUPDUPLICATES', defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean('DISCARDNOTJOINEDPOINTS', 'DISCARDNOTJOINEDPOINTS', defaultValue=True))

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(17, model_feedback)
        results = {}
        outputs = {}

        deletegroupduplicates = self.parameterAsBool(parameters, 'DELETEGROUPDUPLICATES', context)
        splitmultipart = self.parameterAsBool(parameters, 'SPLITMULTIPART', context)

        # Mk_Dissolve
        alg_params = {
            'FIELD': parameters['GROUPFIELDS'],
            'INPUT': parameters['INPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Mk_dissolve'] = processing.run('native:dissolve', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Extract vertices KV
        alg_params = {
            'INPUT': parameters['INPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtractVerticesKv'] = processing.run('native:extractvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Add X/Y fields to layer KV
        alg_params = {
            'CRS': parameters['PROJECTION'],
            'INPUT': outputs['ExtractVerticesKv']['OUTPUT'],
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AddXyFieldsToLayerKv'] = processing.run('native:addxyfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Multipart to singleparts MK
        if splitmultipart:
            alg_params = {
                'INPUT': outputs['Mk_dissolve']['OUTPUT'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['MultipartToSinglepartsMk'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Order by expression KV
        alg_params = {
            'ASCENDING': True,
            'EXPRESSION': parameters['SORTEXPRESSIONKV'],
            'INPUT': outputs['AddXyFieldsToLayerKv']['OUTPUT'],
            'NULLS_FIRST': False,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['OrderByExpressionKv'] = processing.run('native:orderbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Delete duplicates by attribute KV

        if deletegroupduplicates:
            alg_params = {
                'FIELDS': parameters['FIELDSFORDELDUPLICATES'],
                'INPUT': outputs['OrderByExpressionKv']['OUTPUT'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['DeleteDuplicatesByAttributeKv'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Field calculator KV
        alg_params = {
            'FIELD_LENGTH': 70,
            'FIELD_NAME': 'link_id',
            'FIELD_PRECISION': 3,
            'FIELD_TYPE': 2,
            'FORMULA': parameters['LINKEXPRESSION'],
            'INPUT': outputs['DeleteDuplicatesByAttributeKv']['OUTPUT'] if deletegroupduplicates else outputs['OrderByExpressionKv']['OUTPUT'],
            'NEW_FIELD': True,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FieldCalculatorKv'] = processing.run('qgis:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Force right-hand-rule MK
        alg_params = {
            'INPUT': outputs['MultipartToSinglepartsMk']['OUTPUT'] if splitmultipart else outputs['Mk_dissolve']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ForceRighthandruleMk'] = processing.run('native:forcerhr', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # Add autoincremental field MK
        alg_params = {
            'FIELD_NAME': parameters['UCHFIELD'],
            'GROUP_FIELDS': [''],
            'INPUT': outputs['ForceRighthandruleMk']['OUTPUT'],
            'SORT_ASCENDING': False,
            'SORT_EXPRESSION': parameters['SORTEXPRESSIONMK'],
            'SORT_NULLS_FIRST': False,
            'START': 1,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AddAutoincrementalFieldMk'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # Drop field(s) MK 1
        alg_params = {
            'COLUMN': parameters['DROPFIELDSMK'],
            'INPUT': outputs['AddAutoincrementalFieldMk']['OUTPUT'],
            'OUTPUT': parameters['POLYGONS']
        }
        outputs['DropFieldsMk1'] = processing.run('qgis:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['POLYGONS'] = outputs['DropFieldsMk1']['OUTPUT']

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # Extract vertices MK
        alg_params = {
            'INPUT': outputs['DropFieldsMk1']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtractVerticesMk'] = processing.run('native:extractvertices', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # Add X/Y fields to layer MK
        alg_params = {
            'CRS': parameters['PROJECTION'],
            'INPUT': outputs['ExtractVerticesMk']['OUTPUT'],
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AddXyFieldsToLayerMk'] = processing.run('native:addxyfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # Delete duplicates by attribute MK
        alg_params = {
            'FIELDS': parameters['FIELDSFORDELDUPLICATES'],
            'INPUT': outputs['AddXyFieldsToLayerMk']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['DeleteDuplicatesByAttributeMk'] = processing.run('native:removeduplicatesbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            return {}

        # Field calculator MK
        alg_params = {
            'FIELD_LENGTH': 70,
            'FIELD_NAME': 'link_id',
            'FIELD_PRECISION': 3,
            'FIELD_TYPE': 2,
            'FORMULA': parameters['LINKEXPRESSION'],
            'INPUT': outputs['DeleteDuplicatesByAttributeMk']['OUTPUT'],
            'NEW_FIELD': True,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FieldCalculatorMk'] = processing.run('qgis:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            return {}

        # Join attributes by field value KV - MK
        alg_params = {
            'DISCARD_NONMATCHING': parameters['DISCARDNOTJOINEDPOINTS'],
            'FIELD': 'link_id',
            'FIELDS_TO_COPY': [''],
            'FIELD_2': 'link_id',
            'INPUT': outputs['FieldCalculatorKv']['OUTPUT'],
            'INPUT_2': outputs['FieldCalculatorMk']['OUTPUT'],
            'METHOD': 1,
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['JoinAttributesByFieldValueKvMk'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # Add autoincremental field KV - MK
        alg_params = {
            'FIELD_NAME': parameters['POINTFIELD'],
            'GROUP_FIELDS': parameters['UCHFIELD'],
            'INPUT': outputs['JoinAttributesByFieldValueKvMk']['OUTPUT'],
            'SORT_ASCENDING': True,
            'SORT_EXPRESSION': 'vertex_index_2',
            'SORT_NULLS_FIRST': False,
            'START': 1,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AddAutoincrementalFieldKvMk'] = processing.run('native:addautoincrementalfield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            return {}

        # Drop field(s)
        alg_params = {
            'COLUMN': parameters['DROPFIELDSKVMK'],
            'INPUT': outputs['AddAutoincrementalFieldKvMk']['OUTPUT'],
            'OUTPUT': parameters['POINTS']
        }
        outputs['DropFields'] = processing.run('qgis:deletecolumn', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['POINTS'] = outputs['DropFields']['OUTPUT']
        return results

    def name(self):
        return QT_TR_NOOP('Dissolve and extract vertices with preserve attributes (Model)')

    def displayName(self):
        return self.tr2(self.name())

    def group(self):
        return self.tr2(self.groupId())

    def groupId(self):
        return QT_TR_NOOP('Models')

    def createInstance(self):
        return dissolverModel()

    def tr(self, string):
        return QCoreApplication.translate('dissolverModel', string)

    def tr2(self, string):
        return QCoreApplication.translate('@default', string)

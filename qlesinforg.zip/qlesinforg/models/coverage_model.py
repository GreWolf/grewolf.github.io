import os
from typing import Optional, Union

import processing
from processing.modeler.ModelerDialog import ModelerDialog
from qgis.core import QgsFeature, QgsVectorLayer, QgsGeometry, QgsProcessingException

from ..functions import check_layer_exists, load_layer_from_layer, set_style


class Coverage:
    # модель для работы с разрафкой

    # название слоя разграфки
    coverage_name = "Разграфка"

    def __init__(self, plugin_dir: str) -> None:
        # будущий слой разграфки
        self.__coverage: Optional[QgsVectorLayer] = None
        # необходимость загрузки стиля для слоя разграфки
        self.__need_coverage_style = True

        self.__plugin_dir = plugin_dir

        # загрузка модели создания слоя разграфки
        self.__dlg = ModelerDialog()
        self.__dlg.loadModel(os.path.join(self.__plugin_dir, r"qgis_models", "create_grid.model3"))

        # переменные для хранения предыдущих значений входного слоя и масштаба
        self.__old_current_layer: Optional[QgsVectorLayer] = None
        self.__old_scale: Optional[str] = None

    @property
    def coverage(self) -> Optional[QgsVectorLayer]:
        return self.__coverage

    def set_style(self, style_path: str) -> None:
        # установить стиль для слоя разграфки
        set_style(self.__coverage, self.__need_coverage_style, style_path)

    def create_coverage(self, current_layer: QgsVectorLayer, scale: Union[int, float]):
        # создание слоя разграфки

        self.__coverage = check_layer_exists(self.__coverage)

        if not self.__old_current_layer:
            self.__old_current_layer = current_layer

        # если существует слой разграфки и экстент слоя равен экстенту слоя из предудещго запроса,
        # и масштаб равен масштабу из предудещго запроса, то слой разграфки не создаем, т.к.
        # он остается таким же
        if not ((current_layer.extent() == self.__old_current_layer.extent())
                and (scale == self.__old_scale) and self.__coverage):
            try:
                temp_layer = processing.run(self.__dlg.model(), {'CRS': current_layer.crs(),
                                                               'INPUT': current_layer,
                                                               'SCALE': scale,
                                                               'native:addautoincrementalfield_3:result': 'TEMPORARY_OUTPUT'})[
                    'native:addautoincrementalfield_3:result']
            except QgsProcessingException:
                # если длина стороны квадрата разграфки больше чем стороны экстента входного слоя
                # то возникает ошибка в алгоритме.
                temp_layer = QgsVectorLayer("MultiPolygon?crs=epsg:4326", "result", "memory")
                feat = QgsFeature()
                feat.setGeometry(QgsGeometry.fromRect(current_layer.extent()))
                temp_layer.dataProvider().addFeatures([feat])

            self.__coverage, self.__need_coverage_style = load_layer_from_layer(self.__coverage, temp_layer,
                                                                                self.coverage_name)

            self.__old_current_layer = current_layer.clone()
            self.__old_scale = scale

    def coverage_as_lines(self) -> Optional[QgsVectorLayer]:
        # возвращает слой разграфки как линии

        if self.__coverage:

            lines = processing.run("native:polygonstolines", {
                'INPUT': self.__coverage,
                'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']

            return lines
        else:
            return None

__author__ = 'seminozhenko.ss'
__date__ = '2020-01-10'
__copyright__ = '(C) 2020 by seminozhenko.ss'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

from PyQt5.QtGui import QIcon
from qgis.core import QgsProcessingProvider

from .algorithms.create_reports.create_reports import createReport
from .algorithms.excel_creator.excel_creator import excelCreator
from .algorithms.extract_vertices.extract_vertices import extractVertices
from .algorithms.compose_vertices.compose_vertices import composeVertices
from .algorithms.dzz_folder_renamer.dzz_folder_renamer import dzzRenamer

import os
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication

class qlesinforgProvider(QgsProcessingProvider):

    def __init__(self, icon: QIcon, plugin_dir: str) -> None:
        """
        Default constructor.
        """
        self.icon = icon

        self.plugin_dir = plugin_dir

        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            os.path.dirname(__file__),
            'i18n',
            'seminozhenko_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        QgsProcessingProvider.__init__(self)

    def unload(self) -> None:
        """
        Unloads the provider. Any tear-down steps required by the provider
        should be implemented here.
        """
        pass

    def loadAlgorithms(self) -> None:
        """
        Loads all algorithms belonging to this provider.
        """
        self.addAlgorithm(extractVertices(self.plugin_dir))
        self.addAlgorithm(excelCreator(self.plugin_dir))
        self.addAlgorithm(createReport(self.plugin_dir))
        self.addAlgorithm(composeVertices(self.plugin_dir))
        self.addAlgorithm(dzzRenamer(self.plugin_dir))

    def id(self) -> str:
        """
        Returns the unique provider id, used for identifying the provider. This
        string should be a unique, short, character only string, eg "qgis" or
        "gdal". This string should not be localised.
        """
        return 'qlesinforg'

    def name(self) -> str:
        """
        Returns the provider name, which is used to describe the provider
        within the GUI.

        This string should be short (e.g. "Lastools") and localised.
        """
        return self.tr('qlesinforg')

    def icon(self) -> QIcon:
        """
        Should return a QIcon which is used for your provider inside
        the Processing toolbox.
        """
        # return QgsProcessingProvider.icon(self)
        return self.icon

    def longName(self) -> str:
        """
        Returns the a longer version of the provider name, which can include
        extra details such as version numbers. E.g. "Lastools LIDAR tools
        (version 2.2.1)". This string should be localised. The default
        implementation returns the same string as name().
        """
        return self.name()
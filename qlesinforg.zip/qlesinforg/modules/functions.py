import os

def prepare_path(path: str, root_dir: str) -> str:
    if path:
        if os.path.isabs(path):
            return os.path.normpath(path)
        else:
            return os.path.normpath(os.path.join(root_dir, path))
    else:
        return ""

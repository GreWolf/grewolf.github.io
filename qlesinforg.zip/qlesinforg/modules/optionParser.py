import os
import json
from typing import Dict


def parseOptions(filepath: str) -> Dict:
    options = {}

    for file in os.listdir(os.path.join(os.path.dirname(filepath), "options")):
        filename, extension = os.path.splitext(file)
        if extension == ".json":
            with open(os.path.join(os.path.dirname(filepath), "options", file), encoding="utf-8") as jfile:
                options.update({filename: json.load(jfile)})

    return options

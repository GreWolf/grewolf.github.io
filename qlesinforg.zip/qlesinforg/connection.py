connection = {"aHost": "82.148.12.172",
              "aPort": "5432",
              "aDatabase": "gis",
              "aUsername": "qgis",
              "aPassword": "LvlgCuHAA"}
